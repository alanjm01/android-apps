
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameState, Duck, DuckStatus, GameStats, DuckType, HighScore } from './types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  DUCK_WIDTH, 
  DUCK_HEIGHT, 
  DUCK_COLORS, 
  DUCK_POINTS,
  INITIAL_STATS,
  DUCKS_PER_ROUND,
  WIN_REQUIREMENT,
  LEVEL_THEMES,
  getLevelFromRound
} from './constants';
import { drawDuck, drawDog, drawTree } from './components/DuckSprite';
import { getHunterCommentary } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [stats, setStats] = useState<GameStats>(INITIAL_STATS);
  const [startingRound, setStartingRound] = useState<number>(1);
  const [commentary, setCommentary] = useState<string>("READY?");
  const [highScores, setHighScores] = useState<HighScore[]>([]);
  const [preferredThemeIdx, setPreferredThemeIdx] = useState<number | 'dynamic'>('dynamic');
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ducksRef = useRef<Duck[]>([]);
  const requestRef = useRef<number>();
  const lastSpawnTime = useRef<number>(0);
  const ducksSpawnedInRound = useRef<number>(0);
  const dogAnim = useRef({ y: CANVAS_HEIGHT, phase: 'idle', startTime: 0 });
  const starsRef = useRef<{ x: number, y: number, size: number }[]>([]);

  // Generate stars once
  useEffect(() => {
    const stars = [];
    for (let i = 0; i < 50; i++) {
      stars.push({
        x: Math.random() * CANVAS_WIDTH,
        y: Math.random() * CANVAS_HEIGHT * 0.6,
        size: Math.random() * 2 + 1
      });
    }
    starsRef.current = stars;
  }, []);
  
  // Audio setup
  const audioCtx = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtx.current) {
      audioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtx.current.state === 'suspended') {
      audioCtx.current.resume();
    }
  };

  const playSound = (type: 'shoot' | 'hit' | 'miss' | 'quack' | 'falling') => {
    if (!audioCtx.current) return;
    const ctx = audioCtx.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    switch (type) {
      case 'shoot':
        osc.type = 'square';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.1);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
        break;
      case 'hit':
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
        break;
      case 'miss':
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(100, now);
        osc.frequency.linearRampToValueAtTime(50, now + 0.3);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
        break;
      case 'quack':
        osc.type = 'square';
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.setValueAtTime(450, now + 0.05);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
        break;
      case 'falling':
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(100, now + 0.5);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
        break;
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem('duck-hunt-high-scores');
    if (saved) {
      setHighScores(JSON.parse(saved));
    }
  }, []);

  const saveHighScore = useCallback((score: number) => {
    const newScore: HighScore = { score, date: new Date().toLocaleDateString() };
    const updated = [...highScores, newScore]
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
    setHighScores(updated);
    localStorage.setItem('duck-hunt-high-scores', JSON.stringify(updated));
  }, [highScores]);

  const fetchCommentary = useCallback(async (currentStats: GameStats) => {
    const text = await getHunterCommentary(
        currentStats.score, 
        currentStats.round, 
        currentStats.ducksHit / Math.max(1, ducksSpawnedInRound.current)
    );
    setCommentary(text);
  }, []);

  const resetRound = useCallback((roundOverride?: number) => {
    ducksRef.current = [];
    ducksSpawnedInRound.current = 0;
    const activeRound = roundOverride || stats.round;
    setStats(prev => ({ ...prev, round: activeRound, ammo: 3, ducksHit: 0 }));
    fetchCommentary({ ...stats, round: activeRound, ducksHit: 0 });
  }, [stats, fetchCommentary]);

  const startGame = () => {
    initAudio();
    const initialWithRound = { ...INITIAL_STATS, round: startingRound };
    setStats(initialWithRound);
    setGameState(GameState.DOG_INTRO);
    dogAnim.current = { y: CANVAS_HEIGHT, phase: 'UP', startTime: Date.now() };
    resetRound(startingRound);
  };

  const spawnDuck = useCallback(() => {
    if (ducksSpawnedInRound.current >= DUCKS_PER_ROUND) return;
    
    const rand = Math.random();
    let type = DuckType.STANDARD;
    if (rand < 0.1) type = DuckType.FAST;
    else if (rand < 0.2) type = DuckType.ZIGZAG;
    else if (rand < 0.4) type = DuckType.SLOW;

    const side = Math.random() > 0.5 ? 1 : -1;
    const roundMult = 1 + (stats.round * 0.1);
    
    let speedMult = 1;
    if (type === DuckType.FAST) speedMult = 1.8;
    if (type === DuckType.SLOW) speedMult = 0.6;
    if (type === DuckType.ZIGZAG) speedMult = 1.1;

    // Modified spawn to be clearly at the edges but visible instantly
    const spawnX = side === 1 ? 0 : CANVAS_WIDTH - DUCK_WIDTH;

    const newDuck: Duck = {
      id: Date.now() + Math.random(),
      type: type,
      x: spawnX,
      y: CANVAS_HEIGHT * 0.2 + Math.random() * (CANVAS_HEIGHT * 0.4),
      vx: side * (3 + Math.random() * 2) * speedMult * roundMult,
      vy: (Math.random() - 0.5) * 3 * speedMult * roundMult,
      status: DuckStatus.ALIVE,
      width: DUCK_WIDTH,
      height: DUCK_HEIGHT,
      color: DUCK_COLORS[type],
      flapFrame: 0,
      direction: side,
      zigzagOffset: Math.random() * Math.PI * 2,
      hitAnimationTimer: 0
    };
    
    ducksRef.current.push(newDuck);
    ducksSpawnedInRound.current++;
    playSound('quack');
  }, [stats.round]);

  const handleShoot = (e: React.MouseEvent | React.TouchEvent) => {
    if (gameState !== GameState.PLAYING || stats.ammo <= 0) return;
    initAudio();
    playSound('shoot');

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;
    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    setStats(prev => ({ ...prev, ammo: prev.ammo - 1 }));

    let hitOccurred = false;

    ducksRef.current.forEach(duck => {
      if (duck.status === DuckStatus.ALIVE) {
        if (x >= duck.x && x <= duck.x + duck.width && y >= duck.y && y <= duck.y + duck.height) {
          duck.status = DuckStatus.HIT;
          duck.hitAnimationTimer = 20; // Show hit effect for 20 frames
          duck.vx = 0;
          duck.vy = 0;
          hitOccurred = true;
          const points = DUCK_POINTS[duck.type];
          setStats(prev => ({ 
            ...prev, 
            score: prev.score + (points * prev.round),
            ducksHit: prev.ducksHit + 1 
          }));
          playSound('hit');
        }
      }
    });

    if (!hitOccurred) {
      playSound('miss');
    }
  };

  const update = useCallback((time: number) => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    const currentLevelIdx = preferredThemeIdx === 'dynamic' 
        ? getLevelFromRound(stats.round) 
        : preferredThemeIdx;
    
    const theme = LEVEL_THEMES[currentLevelIdx];

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    if (theme.skyGradient) {
      const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT * 0.8);
      grad.addColorStop(0, theme.skyGradient[0]);
      grad.addColorStop(1, theme.skyGradient[1]);
      ctx.fillStyle = grad;
    } else {
      ctx.fillStyle = theme.skyColor;
    }
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    if (theme.showStars) {
      ctx.fillStyle = "#ffffff";
      starsRef.current.forEach(star => {
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    if (theme.showMist) {
      ctx.fillStyle = "rgba(255,255,255,0.2)";
      ctx.fillRect(0, CANVAS_HEIGHT * 0.4, CANVAS_WIDTH, CANVAS_HEIGHT * 0.4);
    }

    // Decoration tree
    drawTree(ctx, CANVAS_WIDTH - 150, CANVAS_HEIGHT - 120, theme.detailColor, theme.groundColor);

    if (gameState === GameState.DOG_INTRO || gameState === GameState.ROUND_WAIT) {
        const elapsed = Date.now() - dogAnim.current.startTime;
        if (dogAnim.current.phase === 'UP') {
            dogAnim.current.y = Math.max(CANVAS_HEIGHT - 180, CANVAS_HEIGHT - (elapsed / 1000) * 300);
            if (elapsed > 1000) dogAnim.current.phase = 'DOWN';
        } else if (dogAnim.current.phase === 'DOWN') {
            dogAnim.current.y = Math.min(CANVAS_HEIGHT, (CANVAS_HEIGHT - 180) + ((elapsed - 1000) / 1000) * 300);
            if (elapsed > 2000) {
                setGameState(GameState.PLAYING);
                lastSpawnTime.current = time;
            }
        }
        drawDog(ctx, CANVAS_WIDTH / 2, dogAnim.current.y, 'INTRO');
    }

    if (gameState === GameState.PLAYING) {
      // Logic for spawning ducks in batches
      if (time - lastSpawnTime.current > 2000 && ducksRef.current.filter(d => d.status === DuckStatus.ALIVE || d.status === DuckStatus.HIT).length === 0) {
        if (ducksSpawnedInRound.current < DUCKS_PER_ROUND) {
          // Spawn a pair of ducks if possible
          spawnDuck();
          if (ducksSpawnedInRound.current < DUCKS_PER_ROUND) {
            spawnDuck();
          }
        } else if (ducksRef.current.every(d => d.status === DuckStatus.ESCAPED || d.status === DuckStatus.FALLING || d.y > CANVAS_HEIGHT)) {
           if (stats.ducksHit >= WIN_REQUIREMENT) {
                setGameState(GameState.ROUND_WAIT);
                dogAnim.current = { y: CANVAS_HEIGHT, phase: 'UP', startTime: Date.now() };
                resetRound();
           } else {
                setGameState(GameState.GAME_OVER);
                saveHighScore(stats.score);
           }
        }
        lastSpawnTime.current = time;
      }

      ducksRef.current.forEach(duck => {
        if (duck.status === DuckStatus.ALIVE) {
          duck.x += duck.vx;
          
          if (duck.type === DuckType.ZIGZAG) {
            duck.y += duck.vy + Math.sin((time / 100) + (duck.zigzagOffset || 0)) * 5;
          } else {
            duck.y += duck.vy;
          }

          duck.flapFrame++;

          // Bounce off top and bottom (within reason)
          if (duck.y < 0 || duck.y > CANVAS_HEIGHT * 0.7) duck.vy *= -1;
          
          // Escape boundaries
          if (duck.x > CANVAS_WIDTH + DUCK_WIDTH || duck.x < -DUCK_WIDTH * 2) {
            duck.status = DuckStatus.ESCAPED;
          }
          
          if (stats.ammo <= 0 && duck.status === DuckStatus.ALIVE) {
             duck.vy = -10;
             duck.vx *= 0.5;
             if (duck.y < -150) duck.status = DuckStatus.ESCAPED;
          }
        } else if (duck.status === DuckStatus.HIT) {
            if (duck.hitAnimationTimer > 0) {
                duck.hitAnimationTimer--;
            } else {
                duck.status = DuckStatus.FALLING;
                playSound('falling');
            }
        } else if (duck.status === DuckStatus.FALLING) {
            duck.y += 12;
        }

        drawDuck(ctx, duck);
      });
    }

    // Draw foreground layer
    ctx.fillStyle = theme.groundColor;
    ctx.fillRect(0, CANVAS_HEIGHT - 100, CANVAS_WIDTH, 100);
    ctx.fillStyle = theme.detailColor;
    ctx.fillRect(0, CANVAS_HEIGHT - 120, CANVAS_WIDTH, 20);

    requestRef.current = requestAnimationFrame(update);
  }, [gameState, spawnDuck, stats.ammo, stats.ducksHit, stats.round, resetRound, stats.score, saveHighScore, preferredThemeIdx]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => cancelAnimationFrame(requestRef.current!);
  }, [update]);

  const getCurrentTheme = () => {
    if (preferredThemeIdx === 'dynamic') {
      return LEVEL_THEMES[getLevelFromRound(gameState === GameState.START ? startingRound : stats.round)];
    }
    return LEVEL_THEMES[preferredThemeIdx];
  };

  const currentLevelTheme = getCurrentTheme();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black overflow-hidden select-none">
      <div className="relative w-full max-w-[800px] aspect-[4/3] overflow-hidden border-4 border-gray-800 shadow-2xl" style={{ backgroundColor: currentLevelTheme.skyColor }}>
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="w-full h-full cursor-crosshair touch-none"
          onClick={handleShoot}
          onTouchStart={handleShoot}
        />

        {/* HUD - Top Bar */}
        <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-start pointer-events-none">
          <div className="flex flex-col gap-1">
            <div className="bg-black/50 p-2 rounded border-2 border-white text-white text-[8px] md:text-[10px]">
              LVL: {stats.round}
            </div>
            <div className="bg-yellow-600/80 p-1 rounded border-2 border-white text-white text-[6px] md:text-[8px] text-center">
              {currentLevelTheme.name}
            </div>
          </div>
          <div className="bg-black/50 p-2 rounded border-2 border-white text-white text-center">
            <div className="text-[8px] mb-1">SCORE</div>
            <div className="text-xs md:text-lg">{stats.score.toString().padStart(6, '0')}</div>
          </div>
          <div className="bg-black/50 p-2 rounded border-2 border-white text-white text-[8px] md:text-[10px]">
             HIT: {stats.ducksHit}/{DUCKS_PER_ROUND}
          </div>
        </div>

        {/* HUD - Bottom Bar */}
        <div className="absolute bottom-4 left-0 w-full flex justify-center items-center gap-4 md:gap-8 pointer-events-none">
          <div className="bg-black/80 px-2 py-1 md:px-4 md:py-2 border-2 border-white rounded flex items-center gap-2">
            <span className="text-white text-[8px] md:text-xs">SHOT</span>
            <div className="flex gap-1">
              {[...Array(3)].map((_, i) => (
                <div 
                  key={i} 
                  className={`w-2 h-4 md:w-3 md:h-5 border border-white ${i < stats.ammo ? 'bg-red-500' : 'bg-transparent'}`}
                />
              ))}
            </div>
          </div>
          <div className="bg-black/80 px-2 py-1 md:px-4 md:py-2 border-2 border-white rounded max-w-[200px]">
             <div className="text-white text-[8px] text-center opacity-70">AI DOG SAYS:</div>
             <div className="text-white text-[8px] md:text-[10px] text-center italic">
                "{commentary}"
             </div>
          </div>
        </div>

        {/* Screens */}
        {gameState === GameState.START && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center text-white p-4 text-center overflow-y-auto backdrop-blur-md">
            <h1 className="text-2xl md:text-5xl mb-4 text-yellow-400 retro-text animate-pulse">DUCK HUNTER</h1>
            
            <div className="w-full max-w-[600px] grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-gray-900/90 p-3 border-2 border-white rounded-lg shadow-xl">
                  <h3 className="text-[10px] text-yellow-500 mb-2 tracking-widest uppercase">Environment</h3>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    <button 
                      onClick={() => setPreferredThemeIdx('dynamic')}
                      className={`relative flex flex-col items-center gap-1 p-1.5 border-2 rounded transition-all hover:scale-105 ${preferredThemeIdx === 'dynamic' ? 'border-yellow-400 bg-yellow-400/20' : 'border-gray-600 bg-black/60 hover:border-white'}`}
                    >
                      <div className="w-full aspect-square bg-gradient-to-tr from-blue-500 via-orange-400 to-indigo-900 rounded-sm border border-white/20" />
                      <span className="text-[6px] md:text-[7px] mt-1 truncate w-full uppercase">Auto</span>
                    </button>
                    {LEVEL_THEMES.map((t, idx) => (
                      <button 
                        key={idx}
                        onClick={() => setPreferredThemeIdx(idx)}
                        className={`relative flex flex-col items-center gap-1 p-1.5 border-2 rounded transition-all hover:scale-105 ${preferredThemeIdx === idx ? 'border-yellow-400 bg-yellow-400/20' : 'border-gray-600 bg-black/60 hover:border-white'}`}
                      >
                        <div 
                          className="w-full aspect-square rounded-sm border border-white/20" 
                          style={{ 
                            background: t.skyGradient 
                              ? `linear-gradient(to bottom, ${t.skyGradient[0]}, ${t.skyGradient[1]})` 
                              : t.skyColor 
                          }} 
                        />
                        <span className="text-[6px] md:text-[7px] mt-1 truncate w-full uppercase">{t.name.split(' ')[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-900/90 p-3 border-2 border-white rounded-lg shadow-xl">
                  <h3 className="text-[10px] text-yellow-500 mb-2 tracking-widest uppercase">Difficulty Level</h3>
                  <div className="flex items-center justify-between gap-2">
                    <button 
                      onClick={() => setStartingRound(Math.max(1, startingRound - 1))}
                      className="w-10 h-10 bg-black border-2 border-white hover:bg-gray-800 active:bg-gray-700 flex items-center justify-center text-xl font-bold"
                    >
                      -
                    </button>
                    <div className="flex flex-col items-center">
                        <span className="text-xl md:text-2xl font-bold text-white leading-none">{startingRound}</span>
                        <span className="text-[6px] text-gray-400 mt-1 uppercase">Lv</span>
                    </div>
                    <button 
                      onClick={() => setStartingRound(Math.min(99, startingRound + 1))}
                      className="w-10 h-10 bg-black border-2 border-white hover:bg-gray-800 active:bg-gray-700 flex items-center justify-center text-xl font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-gray-900/90 p-3 border-2 border-white rounded-lg shadow-xl h-full flex flex-col">
                <h3 className="text-[10px] text-yellow-500 mb-2 tracking-widest uppercase">Leaderboard</h3>
                <div className="flex-1 overflow-y-auto max-h-[160px] md:max-h-full space-y-2 pr-1">
                  {highScores.length > 0 ? (
                    highScores.map((hs, i) => (
                      <div key={i} className="flex justify-between items-center text-[8px] md:text-[10px] bg-black/40 p-2 rounded border border-white/5">
                        <span className="flex items-center gap-2">
                            <span className="text-yellow-600 font-bold">{i + 1}.</span> 
                            {hs.score.toString().padStart(6, '0')}
                        </span>
                        <span className="opacity-40 text-[6px] md:text-[8px] uppercase">{hs.date}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-[8px] opacity-30 py-4 italic text-center">NO DATA</p>
                  )}
                </div>
              </div>
            </div>

            <button 
              onClick={startGame}
              className="mt-8 bg-red-600 hover:bg-red-700 text-white px-10 py-3 md:px-14 md:py-5 border-b-8 border-red-900 active:border-b-0 active:translate-y-2 transition-all text-sm md:text-xl font-bold tracking-widest shadow-2xl"
            >
              START HUNTING
            </button>
          </div>
        )}

        {gameState === GameState.GAME_OVER && (
          <div className="absolute inset-0 bg-red-900/95 flex flex-col items-center justify-center text-white text-center p-6 backdrop-blur-md">
            <h2 className="text-4xl md:text-6xl mb-6 text-white retro-text italic">GAME OVER</h2>
            <div className="bg-black/60 p-6 rounded-lg border-2 border-white mb-8">
                <p className="text-sm md:text-xl text-yellow-400 mb-1 uppercase tracking-tighter">Final Score</p>
                <p className="text-3xl md:text-5xl font-bold">{stats.score.toString().padStart(6, '0')}</p>
            </div>
            <p className="mb-10 text-xs md:text-sm opacity-80 max-w-[300px]">TARGET: HIT {WIN_REQUIREMENT} DUCKS PER BATCH TO SURVIVE</p>
            <button 
              onClick={startGame}
              className="bg-white text-black px-12 py-5 border-b-8 border-gray-400 active:border-b-0 active:translate-y-2 transition-all font-bold tracking-widest text-lg"
            >
              RESTART
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 text-gray-600 text-[7px] md:text-[9px] text-center px-4 max-w-lg leading-loose uppercase tracking-widest opacity-60">
        Master your chosen difficulty in static mode! <br/>
        Score as high as possible in a single session.
      </div>
    </div>
  );
};

export default App;
