
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getHunterCommentary(score: number, round: number, hitRate: number) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are the snarky dog from the classic Duck Hunt game. 
      The player's score is ${score}, current round is ${round}, and their hit rate is ${Math.round(hitRate * 100)}%. 
      Give a short (under 15 words) retro-style snarky or encouraging comment.`,
      config: {
        maxOutputTokens: 50,
        temperature: 0.8,
      }
    });
    return response.text?.trim() || "GET EM TIGER!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "NICE SHOOTING!";
  }
}
