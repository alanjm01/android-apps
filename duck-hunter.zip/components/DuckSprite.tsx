
import React from 'react';

// Helper to draw on canvas.

export const drawDuck = (ctx: CanvasRenderingContext2D, duck: any) => {
  const { x, y, width, height, color, flapFrame, direction, status, hitAnimationTimer } = duck;

  ctx.save();
  ctx.translate(x + width / 2, y + height / 2);
  if (direction === -1) ctx.scale(-1, 1);

  let currentFill = color;

  if (status === 'HIT') {
    // Rapid spin effect
    ctx.rotate(hitAnimationTimer * 0.8);
    // Flash effect: switch to white every 4 frames
    if (Math.floor(hitAnimationTimer / 4) % 2 === 0) {
      currentFill = '#ffffff';
    }
  } else if (status === 'FALLING') {
    ctx.rotate(Math.PI / 2);
  }

  // Body
  ctx.fillStyle = currentFill;
  ctx.fillRect(-20, -10, 40, 20);

  // Head
  ctx.fillStyle = currentFill;
  ctx.fillRect(15, -25, 20, 20);

  // Neck (green for mallard look)
  ctx.fillStyle = status === 'HIT' && Math.floor(hitAnimationTimer / 4) % 2 === 0 ? '#ffffff' : '#006600';
  ctx.fillRect(10, -15, 10, 10);

  // Beak
  ctx.fillStyle = '#ffcc00';
  ctx.fillRect(35, -20, 10, 8);

  // Eye
  ctx.fillStyle = '#000';
  ctx.fillRect(25, -22, 4, 4);

  // Wing (animated)
  ctx.fillStyle = status === 'HIT' && Math.floor(hitAnimationTimer / 4) % 2 === 0 ? '#ff0000' : '#fff';
  if (status === 'ALIVE') {
    const flapY = Math.sin(flapFrame * 0.5) * 10;
    ctx.fillRect(-15, -15 + flapY, 25, 15);
  } else if (status === 'HIT') {
    ctx.fillRect(-15, -15, 25, 15);
  } else if (status === 'FALLING') {
    ctx.fillRect(-15, -15, 25, 15);
  }

  ctx.restore();
};

export const drawDog = (ctx: CanvasRenderingContext2D, x: number, y: number, mode: 'INTRO' | 'SUCCESS' | 'LAUGH') => {
    ctx.save();
    ctx.translate(x, y);

    // Simplistic retro dog
    ctx.fillStyle = '#663300';
    // Body
    ctx.fillRect(-30, 0, 60, 50);
    // Head
    ctx.fillRect(-25, -40, 50, 45);
    // Ears
    ctx.fillStyle = '#442200';
    ctx.fillRect(-35, -35, 15, 30);
    ctx.fillRect(20, -35, 15, 30);
    // Snout
    ctx.fillStyle = '#d2b48c';
    ctx.fillRect(-15, -15, 30, 20);
    // Nose
    ctx.fillStyle = '#000';
    ctx.fillRect(-5, -18, 10, 6);

    if (mode === 'LAUGH') {
        // Laughing mouth
        ctx.fillStyle = '#ff0000';
        ctx.fillRect(-10, -5, 20, 10);
    } else if (mode === 'SUCCESS') {
        // Holding ducks (green blobs)
        ctx.fillStyle = '#006600';
        ctx.fillRect(-45, -20, 20, 15);
        ctx.fillRect(25, -20, 20, 15);
    }

    ctx.restore();
};

export const drawTree = (ctx: CanvasRenderingContext2D, x: number, y: number, leafColor: string, trunkColor: string) => {
  ctx.save();
  ctx.translate(x, y);

  // Trunk
  ctx.fillStyle = trunkColor;
  ctx.fillRect(-10, 0, 20, 60);

  // Leaves
  ctx.fillStyle = leafColor;
  // Simplistic pixel-art style triangles
  ctx.beginPath();
  ctx.moveTo(0, -80);
  ctx.lineTo(40, -30);
  ctx.lineTo(-40, -30);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(0, -50);
  ctx.lineTo(50, 10);
  ctx.lineTo(-50, 10);
  ctx.fill();

  ctx.restore();
};
