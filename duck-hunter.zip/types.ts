
export enum GameState {
  START = 'START',
  PLAYING = 'PLAYING',
  DOG_INTRO = 'DOG_INTRO',
  ROUND_WAIT = 'ROUND_WAIT',
  GAME_OVER = 'GAME_OVER'
}

export enum DuckStatus {
  ALIVE = 'ALIVE',
  HIT = 'HIT',
  FALLING = 'FALLING',
  ESCAPED = 'ESCAPED'
}

export enum DuckType {
  STANDARD = 'STANDARD',
  FAST = 'FAST',
  SLOW = 'SLOW',
  ZIGZAG = 'ZIGZAG'
}

export interface Duck {
  id: number;
  type: DuckType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  status: DuckStatus;
  width: number;
  height: number;
  color: string;
  flapFrame: number;
  direction: number; // 1 for right, -1 for left
  zigzagOffset?: number;
  hitAnimationTimer: number;
}

export interface GameStats {
  score: number;
  round: number;
  ducksHit: number;
  ammo: number;
  misses: number;
}

export interface HighScore {
  score: number;
  date: string;
}
