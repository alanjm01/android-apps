
export const CANVAS_WIDTH = 800;
export const CANVAS_HEIGHT = 600;

export const DUCK_WIDTH = 64;
export const DUCK_HEIGHT = 64;

export const DUCK_COLORS = {
  STANDARD: '#884400', // Brown
  FAST: '#ff5555',     // Red
  SLOW: '#5555ff',     // Blue
  ZIGZAG: '#00aa00'    // Green
};

export const DUCK_POINTS = {
  STANDARD: 100,
  FAST: 500,
  SLOW: 50,
  ZIGZAG: 250
};

export const INITIAL_STATS = {
  score: 0,
  round: 1,
  ducksHit: 0,
  ammo: 3,
  misses: 0,
};

export const DUCKS_PER_ROUND = 10;
export const WIN_REQUIREMENT = 6; // Hits required to pass round

export interface LevelTheme {
  name: string;
  skyColor: string;
  skyGradient?: string[];
  groundColor: string;
  detailColor: string;
  showStars?: boolean;
  showMist?: boolean;
}

export const LEVEL_THEMES: LevelTheme[] = [
  {
    name: "SUNNY MEADOW",
    skyColor: "#64b0ff",
    groundColor: "#4ea400",
    detailColor: "#008000",
  },
  {
    name: "SUNSET RIDGE",
    skyColor: "#ff7e5f",
    skyGradient: ["#ff7e5f", "#feb47b"],
    groundColor: "#8b4513",
    detailColor: "#5d2e0d",
  },
  {
    name: "MIDNIGHT WOODS",
    skyColor: "#0c1445",
    skyGradient: ["#0c1445", "#283e51"],
    groundColor: "#0a1a0a",
    detailColor: "#050f05",
    showStars: true,
  },
  {
    name: "FROZEN MARSH",
    skyColor: "#d3d3d3",
    groundColor: "#ffffff",
    detailColor: "#a9a9a9",
    showMist: true,
  }
];

export const getLevelFromRound = (round: number): number => {
  if (round <= 3) return 0;
  if (round <= 6) return 1;
  if (round <= 9) return 2;
  return 3;
};
