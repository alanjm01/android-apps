using UnityEngine;

public class Duck : MonoBehaviour
{
    public float speed = 3f;

    void Update()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }

    void OnMouseDown()
    {
        Destroy(gameObject);
    }
}
