using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject duckPrefab;

    void Start()
    {
        SpawnDuck();
    }

    void SpawnDuck()
    {
        Instantiate(duckPrefab, new Vector2(-8, Random.Range(-3f, 3f)), Quaternion.identity);
    }
}
