package com.example.retroduckhunt

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.random.Random

class Duck {

    var x = Random.nextInt(100, 800).toFloat()
    var y = Random.nextInt(100, 1000).toFloat()
    private val size = 100f
    private val paint = Paint().apply { color = Color.GREEN }

    fun update() {
        x += 5
        if (x > 1000) x = 0f
    }

    fun draw(canvas: Canvas) {
        canvas.drawRect(x, y, x + size, y + size, paint)
    }

    fun isHit(tapX: Float, tapY: Float): Boolean {
        return tapX in x..(x + size) && tapY in y..(y + size)
    }
}
