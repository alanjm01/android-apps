package com.example.retroduckhunt

import android.graphics.Canvas
import android.view.SurfaceHolder

class GameThread(private val holder: SurfaceHolder, private val gameView: GameView) : Thread() {

    var running = false

    override fun run() {
        while (running) {
            val canvas: Canvas? = holder.lockCanvas()
            if (canvas != null) {
                synchronized(holder) {
                    gameView.update()
                    gameView.draw(canvas)
                }
                holder.unlockCanvasAndPost(canvas)
            }
        }
    }
}
