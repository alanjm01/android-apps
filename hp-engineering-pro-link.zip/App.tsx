
import React, { useState } from 'react';
import { 
  History as HistoryIcon, 
  Cpu, 
  ChevronRight, 
  BrainCircuit, 
  Trash2, 
  Settings2,
  HelpCircle,
  MessageSquare,
  Scale,
  ListRestart
} from 'lucide-react';
import CalculatorButton from './components/CalculatorButton';
import { RPNStack, AngleMode, AIResponse, SidebarTab, UNIT_CATEGORIES, Complex } from './types';
import { solveEngineeringProblem } from './services/geminiService';

const App: React.FC = () => {
  // Calculator State
  const initialComplex: Complex = { re: 0, im: 0 };
  const [stack, setStack] = useState<RPNStack>([initialComplex, initialComplex, initialComplex, initialComplex]);
  const [inputBuffer, setInputBuffer] = useState<string>('');
  const [imaginaryBuffer, setImaginaryBuffer] = useState<string>('');
  const [isEnteringImaginary, setIsEnteringImaginary] = useState(false);
  const [angleMode, setAngleMode] = useState<AngleMode>(AngleMode.DEG);
  const [isShift, setIsShift] = useState(false);
  const [history, setHistory] = useState<Complex[]>([]);
  
  // Sidebar State
  const [activeTab, setActiveTab] = useState<SidebarTab>('AI');
  const [aiQuery, setAiQuery] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<AIResponse | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Constants
  const DISPLAY_STACK_LABELS = ['X', 'Y', 'Z', 'T'];

  // Helper: Format complex numbers for display
  const formatComplex = (c: Complex, precision: number = 6) => {
    const re = c.re.toLocaleString(undefined, { maximumFractionDigits: precision });
    if (Math.abs(c.im) < 1e-12) return re;
    const sign = c.im >= 0 ? '+' : '-';
    const im = Math.abs(c.im).toLocaleString(undefined, { maximumFractionDigits: precision });
    return `${re} ${sign} ${im}j`;
  };

  const formatPolar = (c: Complex) => {
    const mag = Math.sqrt(c.re * c.re + c.im * c.im);
    let arg = Math.atan2(c.im, c.re);
    if (angleMode === AngleMode.DEG) {
      arg = arg * (180 / Math.PI);
    }
    return `${mag.toLocaleString(undefined, { maximumFractionDigits: 4 })} ∠ ${arg.toLocaleString(undefined, { maximumFractionDigits: 2 })}°`;
  };

  const pushToStack = (val: Complex, addToHistory: boolean = true) => {
    setStack(prev => [val, prev[0], prev[1], prev[2]]);
    setInputBuffer('');
    setImaginaryBuffer('');
    setIsEnteringImaginary(false);
    if (addToHistory && (val.re !== 0 || val.im !== 0)) {
      setHistory(prev => [val, ...prev.slice(0, 49)]);
    }
  };

  const handleEnter = () => {
    let re = stack[0].re;
    let im = stack[0].im;

    if (inputBuffer !== '') re = parseFloat(inputBuffer);
    if (imaginaryBuffer !== '') im = parseFloat(imaginaryBuffer);

    pushToStack({ re, im });
  };

  const clearStack = () => {
    setStack([initialComplex, initialComplex, initialComplex, initialComplex]);
    setInputBuffer('');
    setImaginaryBuffer('');
    setIsEnteringImaginary(false);
  };

  const handleBinaryOperation = (op: (a: Complex, b: Complex) => Complex) => {
    const x_re = inputBuffer === '' ? stack[0].re : parseFloat(inputBuffer);
    const x_im = imaginaryBuffer === '' ? stack[0].im : parseFloat(imaginaryBuffer);
    const x = { re: x_re, im: x_im };
    const y = stack[1];
    
    const result = op(y, x);
    setStack(prev => [result, prev[2], prev[3], initialComplex]);
    setInputBuffer('');
    setImaginaryBuffer('');
    setIsEnteringImaginary(false);
    setHistory(prev => [result, ...prev.slice(0, 49)]);
  };

  const handleUnaryOperation = (op: (a: Complex) => Complex) => {
    const x_re = inputBuffer === '' ? stack[0].re : parseFloat(inputBuffer);
    const x_im = imaginaryBuffer === '' ? stack[0].im : parseFloat(imaginaryBuffer);
    const x = { re: x_re, im: x_im };
    
    const result = op(x);
    setStack(prev => [result, prev[1], prev[2], prev[3]]);
    setInputBuffer('');
    setImaginaryBuffer('');
    setIsEnteringImaginary(false);
    setHistory(prev => [result, ...prev.slice(0, 49)]);
  };

  const handleDigit = (digit: string) => {
    if (isEnteringImaginary) {
      if (digit === '.' && imaginaryBuffer.includes('.')) return;
      setImaginaryBuffer(prev => prev + digit);
    } else {
      if (digit === '.' && inputBuffer.includes('.')) return;
      setInputBuffer(prev => prev + digit);
    }
  };

  // --- Complex Core Operations ---
  const cAdd = (a: Complex, b: Complex): Complex => ({ re: a.re + b.re, im: a.im + b.im });
  const cSub = (a: Complex, b: Complex): Complex => ({ re: a.re - b.re, im: a.im - b.im });
  const cMul = (a: Complex, b: Complex): Complex => ({ 
    re: a.re * b.re - a.im * b.im, 
    im: a.re * b.im + a.im * b.re 
  });
  const cDiv = (a: Complex, b: Complex): Complex => {
    const denom = b.re * b.re + b.im * b.im;
    if (denom === 0) return { re: NaN, im: NaN };
    return {
      re: (a.re * b.re + a.im * b.im) / denom,
      im: (a.im * b.re - a.re * b.im) / denom
    };
  };

  // Complex Exponentiation: exp(z) = exp(x) * (cos(y) + i sin(y))
  const cExp = (z: Complex): Complex => {
    const expRe = Math.exp(z.re);
    return {
      re: expRe * Math.cos(z.im),
      im: expRe * Math.sin(z.im)
    };
  };

  // Complex Logarithms
  const cLn = (z: Complex): Complex => {
    const r = Math.sqrt(z.re * z.re + z.im * z.im);
    if (r === 0) return { re: -Infinity, im: 0 };
    return {
      re: Math.log(r),
      im: Math.atan2(z.im, z.re)
    };
  };

  const cLog10 = (z: Complex): Complex => {
    const lnZ = cLn(z);
    const ln10 = Math.log(10);
    return {
      re: lnZ.re / ln10,
      im: lnZ.im / ln10
    };
  };

  // Complex Power: y^x = exp(x * ln(y))
  const cPow = (y: Complex, x: Complex): Complex => {
    if (x.re === 0 && x.im === 0) return { re: 1, im: 0 };
    if (y.re === 0 && y.im === 0) return { re: 0, im: 0 };
    return cExp(cMul(x, cLn(y)));
  };

  const cConj = (z: Complex): Complex => ({ re: z.re, im: -z.im });
  
  const cAbs = (z: Complex): Complex => ({ re: Math.sqrt(z.re * z.re + z.im * z.im), im: 0 });
  const cArg = (z: Complex): Complex => {
    let arg = Math.atan2(z.im, z.re);
    if (angleMode === AngleMode.DEG) arg = arg * (180 / Math.PI);
    return { re: arg, im: 0 };
  };

  // Trigo & Math Helpers (Real-based but operating on Complex input)
  const toRad = (val: number) => angleMode === AngleMode.DEG ? val * (Math.PI / 180) : val;
  const fromRad = (val: number) => angleMode === AngleMode.DEG ? val * (180 / Math.PI) : val;
  const factorial = (n: number): number => {
    if (n < 0) return NaN;
    if (n === 0) return 1;
    let res = 1;
    for (let i = 2; i <= Math.floor(n); i++) res *= i;
    return res;
  };

  // Button Action Router
  const btnAction = (primary: () => void, shifted?: () => void) => {
    if (isShift && shifted) {
      shifted();
      setIsShift(false);
    } else {
      primary();
    }
  };

  // AI Logic
  const handleAiSolve = async () => {
    if (!aiQuery.trim()) return;
    setIsAiLoading(true);
    try {
      const result = await solveEngineeringProblem(aiQuery);
      setAiResult(result);
    } catch (error) {
      console.error("AI Solving failed", error);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Unit Conversion
  const convertUnit = (fromFactor: number, fromOffset: number = 0, toFactor: number, toOffset: number = 0) => {
    const x = inputBuffer === '' ? stack[0].re : parseFloat(inputBuffer);
    const baseValue = (x - fromOffset) / fromFactor;
    const result = (baseValue * toFactor) + toOffset;
    handleUnaryOperation(c => ({ re: result, im: c.im }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-zinc-950 text-zinc-200">
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-indigo-500 blur-[120px] rounded-full"></div>
        <div className="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-orange-500 blur-[120px] rounded-full"></div>
      </div>

      <div className="relative flex flex-col md:flex-row gap-8 w-full max-w-6xl z-10 transition-all">
        
        {/* Main Calculator Body */}
        <div className="bg-zinc-900 p-6 rounded-[2.5rem] shadow-2xl border border-zinc-800 flex flex-col gap-6 flex-1 min-w-[340px] max-w-[420px] mx-auto">
          
          <div className="flex justify-between items-center px-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-zinc-800 rounded-lg flex items-center justify-center border border-zinc-700">
                <Cpu size={18} className="text-orange-500" />
              </div>
              <span className="font-bold tracking-tighter text-lg">PRO-LINK <span className="text-zinc-500 font-normal">ENG-X</span></span>
            </div>
            <div className="flex gap-2 items-center">
              <button 
                className={`text-[10px] font-bold px-2 py-1 rounded transition-colors ${angleMode === AngleMode.DEG ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-500'}`} 
                onClick={() => setAngleMode(AngleMode.DEG)}
              >DEG</button>
              <button 
                className={`text-[10px] font-bold px-2 py-1 rounded transition-colors ${angleMode === AngleMode.RAD ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-500'}`} 
                onClick={() => setAngleMode(AngleMode.RAD)}
              >RAD</button>
            </div>
          </div>

          {/* LCD Display */}
          <div className="bg-[#a4b494] p-4 rounded-xl shadow-inner border-[3px] border-zinc-800 h-52 flex flex-col justify-end text-zinc-900 lcd-font relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1/2 bg-white/10 -skew-y-3"></div>
            <div className="absolute top-2 right-4 flex gap-2">
              {isShift && <span className="text-[10px] font-black bg-orange-600 text-white px-1 rounded">SHIFT</span>}
              {stack[0].im !== 0 && <span className="text-[10px] font-black bg-indigo-600 text-white px-1 rounded">CPLX</span>}
            </div>
            
            <div className="flex flex-col gap-1 w-full text-xs opacity-70 mb-2 font-medium">
              {stack.slice(1).reverse().map((val, idx) => (
                <div key={idx} className="flex justify-between border-b border-black/5">
                  <span>{DISPLAY_STACK_LABELS[3-idx]}:</span>
                  <span>{formatComplex(val, 4)}</span>
                </div>
              ))}
            </div>
            
            <div className="flex justify-between items-baseline mt-1 border-t border-black/10 pt-1">
              <span className="text-base font-bold opacity-50">X:</span>
              <span className="text-2xl font-bold tracking-tight text-right flex-1">
                {isEnteringImaginary ? (
                  <>{inputBuffer || '0'} + <span className="text-indigo-800 underline">{imaginaryBuffer || '0'}</span>j</>
                ) : (
                  inputBuffer ? <>{inputBuffer}</> : formatComplex(stack[0], 8)
                )}
              </span>
            </div>
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-4 gap-2.5">
            <CalculatorButton 
              subLabel="ASIN" label="SIN" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => ({ re: fromRad(Math.sin(toRad(c.re))), im: 0 })),
                () => handleUnaryOperation(c => ({ re: fromRad(Math.asin(c.re)), im: 0 }))
              )} 
            />
            <CalculatorButton 
              subLabel="ACOS" label="COS" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => ({ re: fromRad(Math.cos(toRad(c.re))), im: 0 })),
                () => handleUnaryOperation(c => ({ re: fromRad(Math.acos(c.re)), im: 0 }))
              )} 
            />
            <CalculatorButton 
              subLabel="ATAN" label="TAN" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => ({ re: fromRad(Math.tan(toRad(c.re))), im: 0 })),
                () => handleUnaryOperation(c => ({ re: fromRad(Math.atan(c.re)), im: 0 }))
              )} 
            />
            <CalculatorButton 
              subLabel="MOD" label="1/X" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => cDiv({re: 1, im: 0}, c)),
                () => handleBinaryOperation((y, x) => ({ re: y.re % x.re, im: 0 }))
              )} 
            />

            <CalculatorButton 
              subLabel="LN" label="LOG" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => cLog10(c)),
                () => handleUnaryOperation(c => cLn(c))
              )} 
            />
            <CalculatorButton 
              subLabel="E^Z" label="Y^X" 
              onClick={() => btnAction(
                () => handleBinaryOperation(cPow),
                () => handleUnaryOperation(cExp)
              )} 
            />
            <CalculatorButton 
              subLabel="SQRT" label="X²" 
              onClick={() => btnAction(
                () => handleUnaryOperation(c => cMul(c, c)),
                () => handleUnaryOperation(c => ({ re: Math.sqrt(c.re), im: 0 }))
              )} 
            />
            <CalculatorButton 
              subLabel="ARG" label="ABS" 
              onClick={() => btnAction(
                () => handleUnaryOperation(cAbs),
                () => handleUnaryOperation(cArg)
              )} 
            />

            <CalculatorButton 
              label="f" 
              onClick={() => setIsShift(!isShift)} 
              variant={isShift ? "accent" : "secondary"} 
              className={`transition-colors font-black text-lg ${isShift ? 'bg-orange-500' : ''}`}
            />
            <CalculatorButton label="CLR" onClick={clearStack} variant="secondary" className="text-red-400" />
            <CalculatorButton label="SWAP" onClick={() => setStack(prev => [prev[1], prev[0], prev[2], prev[3]])} variant="secondary" />
            <CalculatorButton label="ROLL" onClick={() => setStack(prev => [prev[1], prev[2], prev[3], prev[0]])} variant="secondary" />

            <div className="grid grid-cols-3 col-span-3 gap-2.5">
              {[7, 8, 9, 4, 5, 6, 1, 2, 3].map(n => (
                <CalculatorButton key={n} label={n.toString()} onClick={() => handleDigit(n.toString())} variant="primary" />
              ))}
              <CalculatorButton label="." onClick={() => handleDigit('.')} variant="primary" />
              <CalculatorButton label="0" onClick={() => handleDigit('0')} variant="primary" />
              <CalculatorButton 
                subLabel="CONJ" 
                label="j" 
                onClick={() => btnAction(
                  () => setIsEnteringImaginary(true),
                  () => handleUnaryOperation(cConj)
                )} 
                variant="accent" 
                className="font-bold text-lg italic" 
              />
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              <CalculatorButton label="/" onClick={() => handleBinaryOperation(cDiv)} variant="action" />
              <CalculatorButton label="*" onClick={() => handleBinaryOperation(cMul)} variant="action" />
              <CalculatorButton label="-" onClick={() => handleBinaryOperation(cSub)} variant="action" />
              <CalculatorButton label="+" onClick={() => handleBinaryOperation(cAdd)} variant="action" />
            </div>

            <CalculatorButton label="PI" onClick={() => pushToStack({ re: Math.PI, im: 0 })} variant="secondary" />
            <CalculatorButton label="ENTER" onClick={handleEnter} variant="accent" className="col-span-2 h-14 text-lg font-black" />
            <CalculatorButton 
              label={<div className="flex items-center gap-1"><BrainCircuit size={16} /> TOOLS</div>} 
              onClick={() => setIsSidebarOpen(true)} 
              variant="action" 
            />
          </div>
        </div>

        {/* Sidebar Logic */}
        <div className={`
          flex flex-col transition-all duration-500 overflow-hidden
          ${isSidebarOpen ? 'w-full md:w-[420px] opacity-100 translate-x-0' : 'w-0 opacity-0 translate-x-12 pointer-events-none'}
        `}>
          <div className="bg-zinc-900 border border-zinc-800 rounded-[2.5rem] p-6 flex flex-col h-[740px] shadow-2xl relative">
            <div className="flex bg-zinc-950/50 p-1 rounded-2xl mb-6">
              {[
                { id: 'AI', icon: <BrainCircuit size={16}/>, label: 'AI Solver' },
                { id: 'HISTORY', icon: <HistoryIcon size={16}/>, label: 'History' },
                { id: 'UNITS', icon: <Scale size={16}/>, label: 'Units' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as SidebarTab)}
                  className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-zinc-800 text-indigo-400 shadow-sm' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                  {tab.icon} <span className="hidden sm:inline">{tab.label}</span>
                </button>
              ))}
              <button onClick={() => setIsSidebarOpen(false)} className="px-3 text-zinc-600 hover:text-white"><Trash2 size={16}/></button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
              {activeTab === 'AI' && (
                <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-right-4 duration-300">
                  <h2 className="text-xl font-bold text-indigo-400">Engineering AI</h2>
                  <textarea 
                    value={aiQuery}
                    onChange={(e) => setAiQuery(e.target.value)}
                    placeholder="e.g. Calculate the impedance of a circuit with 10 ohms and 5mH at 60Hz..."
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-sm h-36 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all resize-none shadow-inner"
                  />
                  <button
                    onClick={handleAiSolve}
                    disabled={isAiLoading || !aiQuery.trim()}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg"
                  >
                    {isAiLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <>Generate Solution <ChevronRight size={18}/></>}
                  </button>

                  {aiResult && (
                    <div className="mt-6 space-y-4">
                      {aiResult.steps.map((step, i) => (
                        <div key={i} className="bg-zinc-950/50 p-4 rounded-2xl border border-zinc-800/50 text-sm">
                          <span className="text-indigo-500 font-black mr-2">{i+1}</span> {step}
                        </div>
                      ))}
                      <div className="p-6 bg-indigo-900/10 border border-indigo-500/20 rounded-3xl">
                        <span className="text-xs font-black text-indigo-400 tracking-widest">Calculated Result</span>
                        <div className="text-3xl font-bold text-white mt-1 mb-4 lcd-font">
                          {aiResult.finalResult.toLocaleString()}
                        </div>
                        <button onClick={() => pushToStack({ re: aiResult.finalResult, im: 0 })} className="w-full bg-indigo-600 py-3 rounded-xl font-bold hover:bg-indigo-500">
                          Push to Stack
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'HISTORY' && (
                <div className="flex flex-col gap-3 animate-in fade-in slide-in-from-right-4 duration-300">
                   <div className="flex justify-between items-center mb-2">
                     <h2 className="text-xl font-bold">Calculation Log</h2>
                     <button onClick={() => setHistory([])} className="text-xs text-zinc-500 hover:text-red-400"><ListRestart size={12}/> Clear</button>
                   </div>
                   {history.map((val, i) => (
                     <div 
                       key={i} 
                       className="w-full bg-zinc-950 border border-zinc-800 p-4 rounded-2xl flex flex-col gap-2 transition-all relative group"
                     >
                       <div className="flex justify-between items-center">
                         <span className="text-zinc-500 text-[10px] font-mono font-black uppercase tracking-widest">Entry #{history.length - i}</span>
                         <button onClick={() => pushToStack(val)} className="text-indigo-400 hover:text-indigo-300 text-xs font-bold uppercase tracking-tighter flex items-center gap-1">
                           Recall <ChevronRight size={12}/>
                         </button>
                       </div>
                       <div className="text-lg font-bold text-zinc-100">{formatComplex(val, 10)}</div>
                       <div className="text-[10px] font-mono text-zinc-500 bg-zinc-900/50 px-2 py-1 rounded inline-block self-start">
                         Polar: {formatPolar(val)}
                       </div>
                     </div>
                   ))}
                </div>
              )}

              {activeTab === 'UNITS' && (
                <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-right-4 duration-300">
                  <h2 className="text-xl font-bold mb-2">Unit Converter</h2>
                  {UNIT_CATEGORIES.map(cat => (
                    <div key={cat.name} className="space-y-3">
                      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-zinc-500 ml-1">{cat.name}</h3>
                      <div className="grid grid-cols-2 gap-2">
                        {cat.units.map(unit => (
                          <button
                            key={unit.name}
                            onClick={() => convertUnit(1, 0, unit.factor, unit.offset)}
                            className="bg-zinc-950 border border-zinc-800 hover:border-indigo-500/50 p-3 rounded-xl text-left transition-all"
                          >
                            <div className="text-xs font-bold truncate">{unit.name}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-6 flex justify-center gap-8 text-[10px] uppercase font-bold text-zinc-600 tracking-widest hidden md:flex">
        <div className="flex items-center gap-2"><Settings2 size={12}/> Shift (f) activates sub-labels</div>
        <div className="flex items-center gap-2"><HistoryIcon size={12}/> History shows Rect & Polar</div>
        <div className="flex items-center gap-2"><HelpCircle size={12}/> Complex Power: y^x = exp(x * ln(y))</div>
      </div>
    </div>
  );
};

export default App;
