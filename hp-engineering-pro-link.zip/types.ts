
export interface Complex {
  re: number;
  im: number;
}

export type RPNStack = [Complex, Complex, Complex, Complex]; // X, Y, Z, T

export enum AngleMode {
  DEG = 'DEG',
  RAD = 'RAD'
}

export interface CalculationResult {
  value: number;
  explanation?: string;
  formula?: string;
}

export interface AIResponse {
  steps: string[];
  finalResult: number;
  rpnSequence: string[];
}

export type SidebarTab = 'AI' | 'HISTORY' | 'UNITS';

export interface UnitCategory {
  name: string;
  units: { name: string; factor: number; base: string; offset?: number }[];
}

export const UNIT_CATEGORIES: UnitCategory[] = [
  {
    name: 'Length',
    units: [
      { name: 'Meters (m)', factor: 1, base: 'm' },
      { name: 'Feet (ft)', factor: 3.28084, base: 'm' },
      { name: 'Inches (in)', factor: 39.3701, base: 'm' },
      { name: 'Kilometers (km)', factor: 0.001, base: 'm' }
    ]
  },
  {
    name: 'Mass',
    units: [
      { name: 'Kilograms (kg)', factor: 1, base: 'kg' },
      { name: 'Pounds (lb)', factor: 2.20462, base: 'kg' },
      { name: 'Grams (g)', factor: 1000, base: 'kg' }
    ]
  },
  {
    name: 'Temperature',
    units: [
      { name: 'Celsius (°C)', factor: 1, base: 'C' },
      { name: 'Fahrenheit (°F)', factor: 1.8, base: 'C', offset: 32 },
      { name: 'Kelvin (K)', factor: 1, base: 'C', offset: 273.15 }
    ]
  },
  {
    name: 'Pressure',
    units: [
      { name: 'Pascals (Pa)', factor: 1, base: 'Pa' },
      { name: 'PSI', factor: 0.000145038, base: 'Pa' },
      { name: 'Bar', factor: 0.00001, base: 'Pa' },
      { name: 'Atm', factor: 0.00000986923, base: 'Pa' }
    ]
  }
];
