
import React from 'react';

interface CalculatorButtonProps {
  label: string | React.ReactNode;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'accent' | 'action';
  className?: string;
  subLabel?: string;
}

const CalculatorButton: React.FC<CalculatorButtonProps> = ({ 
  label, 
  onClick, 
  variant = 'secondary', 
  className = '',
  subLabel
}) => {
  const variants = {
    primary: 'bg-zinc-800 text-white hover:bg-zinc-700',
    secondary: 'bg-zinc-700 text-gray-200 hover:bg-zinc-600',
    accent: 'bg-orange-600 text-white hover:bg-orange-500',
    action: 'bg-indigo-600 text-white hover:bg-indigo-500',
  };

  return (
    <button
      onClick={onClick}
      className={`
        relative flex flex-col items-center justify-center 
        h-14 rounded-md font-semibold text-sm transition-all 
        beveled-btn active:scale-95 select-none
        ${variants[variant]} ${className}
      `}
    >
      {subLabel && (
        <span className="absolute -top-1 right-1 text-[10px] text-orange-400 font-bold uppercase">
          {subLabel}
        </span>
      )}
      <div className="flex items-center justify-center w-full h-full">
        {label}
      </div>
    </button>
  );
};

export default CalculatorButton;
