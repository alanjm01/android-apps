
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse } from "../types";

export const solveEngineeringProblem = async (problem: string): Promise<AIResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Solve the following engineering problem. Provide the response as a JSON object with: 
      1. 'steps': an array of strings explaining the logic.
      2. 'finalResult': a number representing the result.
      3. 'rpnSequence': an array of strings representing the key sequence on an RPN calculator (e.g. ["12", "ENTER", "5", "*"]).
      
      Problem: ${problem}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          steps: { type: Type.ARRAY, items: { type: Type.STRING } },
          finalResult: { type: Type.NUMBER },
          rpnSequence: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["steps", "finalResult", "rpnSequence"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};
