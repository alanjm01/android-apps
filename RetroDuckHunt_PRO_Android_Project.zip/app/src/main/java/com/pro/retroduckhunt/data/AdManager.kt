package com.pro.retroduckhunt.data

import android.app.Activity

object AdManager {

    fun initialize(activity: Activity) {
        // Initialize AdMob here
    }

    fun showInterstitial(activity: Activity) {
        // Show interstitial ad
    }
}
