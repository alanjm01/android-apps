package com.pro.retroduckhunt.skins

object SkinManager {

    fun unlockSkin(id: String) {
        // Unlock skin logic
    }
}
