package com.pro.retroduckhunt.daily

object DailyChallengeManager {

    fun getTodayChallenge(): String {
        return "Score 50 in 60 seconds"
    }
}
