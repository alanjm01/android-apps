package com.pro.retroduckhunt.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.pro.retroduckhunt.data.AdManager
import com.pro.retroduckhunt.leaderboard.LeaderboardManager

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    private val thread: GameThread
    private val duck = Duck()
    private var score = 0

    init {
        holder.addCallback(this)
        thread = GameThread(holder, this)
    }

    fun update() {
        duck.update()
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        canvas.drawColor(Color.CYAN)
        duck.draw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            if (duck.isHit(event.x, event.y)) {
                score++
                LeaderboardManager.submitScore(score)
            }
        }
        return true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        thread.running = true
        thread.start()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        thread.running = false
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
}
