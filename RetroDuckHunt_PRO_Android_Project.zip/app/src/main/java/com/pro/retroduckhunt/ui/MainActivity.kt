package com.pro.retroduckhunt.ui

import android.app.Activity
import android.os.Bundle
import com.pro.retroduckhunt.game.GameView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(GameView(this))
    }
}
