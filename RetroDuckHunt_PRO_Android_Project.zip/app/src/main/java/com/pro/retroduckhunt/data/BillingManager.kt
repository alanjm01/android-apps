package com.pro.retroduckhunt.data

import android.content.Context

object BillingManager {

    fun initialize(context: Context) {
        // Initialize Google Billing
    }

    fun purchaseRemoveAds() {
        // Launch purchase flow
    }
}
