package com.pro.retroduckhunt.leaderboard

object LeaderboardManager {

    fun submitScore(score: Int) {
        // Submit score to Firebase
    }
}
