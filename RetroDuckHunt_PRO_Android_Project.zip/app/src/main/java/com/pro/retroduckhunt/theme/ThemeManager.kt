package com.pro.retroduckhunt.theme

object ThemeManager {

    fun applySeasonalTheme() {
        // Apply seasonal visuals
    }
}
