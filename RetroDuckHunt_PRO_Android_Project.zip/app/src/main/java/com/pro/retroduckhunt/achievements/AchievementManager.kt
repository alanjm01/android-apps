package com.pro.retroduckhunt.achievements

object AchievementManager {

    fun unlock(id: String) {
        // Trigger Play Games achievement
    }
}
