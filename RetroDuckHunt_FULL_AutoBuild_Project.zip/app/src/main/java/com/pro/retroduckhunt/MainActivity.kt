
package com.pro.retroduckhunt

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val textView = TextView(this)
        textView.text = "Retro Duck Hunt PRO - Build Successful!"
        textView.textSize = 24f
        setContentView(textView)
    }
}
