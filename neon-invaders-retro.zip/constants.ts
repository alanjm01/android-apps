
export const CANVAS_WIDTH = 400;
export const CANVAS_HEIGHT = 600;

export const PLAYER_WIDTH = 40;
export const PLAYER_HEIGHT = 20;
export const BASE_PLAYER_SPEED = 5;

export const ALIEN_ROWS = 5;
export const ALIEN_COLS = 8;
export const ALIEN_SIZE = 28;
export const ALIEN_PADDING = 10;
export const ALIEN_OFFSET_TOP = 80;

export const BOSS_WIDTH = 120;
export const BOSS_HEIGHT = 60;
export const BOSS_BASE_HEALTH = 40;

export const BULLET_WIDTH = 4;
export const BULLET_HEIGHT = 12;
export const BULLET_SPEED = 7;

export const POWERUP_SIZE = 20;
export const POWERUP_SPEED = 3;
export const POWERUP_CHANCE = 0.15;

export const COLORS = {
  PLAYER: '#00ffcc',
  SHIELD: '#00ff00',
  ALIEN_GRUNT: '#ff0066',
  ALIEN_ZIGZAG: '#ffff00',
  ALIEN_ELITE: '#00ffff',
  ALIEN_UFO: '#ff00ff',
  ALIEN_BOSS: '#ff3300',
  BOSS_EYE: '#ffffff',
  BULLET: '#ffffff',
  TEXT: '#00ffcc',
  POWERUP_RF: '#ff0000',
  POWERUP_SB: '#0000ff',
  POWERUP_SH: '#00ff00'
};
