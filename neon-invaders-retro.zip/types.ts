
export enum GameState {
  START = 'START',
  BRIEFING = 'BRIEFING',
  PLAYING = 'PLAYING',
  GAME_OVER = 'GAME_OVER',
  VICTORY = 'VICTORY'
}

export interface Entity {
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
}

export enum AlienType {
  GRUNT = 0,
  ZIGZAG = 1,
  ELITE = 2,
  UFO = 3,
  BOSS = 4
}

export interface Alien extends Entity {
  points: number;
  alive: boolean;
  type: AlienType;
  offsetX?: number;
  health?: number;
  maxHealth?: number;
}

export interface Boss extends Entity {
  health: number;
  maxHealth: number;
  phase: number;
  attackTimer: number;
  direction: number;
}

export enum PowerUpType {
  RAPID_FIRE = 'RAPID_FIRE',
  SPEED_BOOST = 'SPEED_BOOST',
  SHIELD = 'SHIELD'
}

export interface PowerUp extends Entity {
  type: PowerUpType;
  dy: number;
}

export interface Bullet extends Entity {
  dy: number;
  dx?: number; // Added for spread shots
  owner: 'player' | 'alien';
}

export interface Particle extends Entity {
  dx: number;
  dy: number;
  life: number;
}

export interface Briefing {
  title: string;
  message: string;
}
