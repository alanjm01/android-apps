
import React, { useEffect, useRef, useCallback } from 'react';
import { 
  CANVAS_WIDTH, CANVAS_HEIGHT, PLAYER_WIDTH, PLAYER_HEIGHT, 
  ALIEN_ROWS, ALIEN_COLS, ALIEN_SIZE, ALIEN_PADDING, ALIEN_OFFSET_TOP,
  BULLET_WIDTH, BULLET_HEIGHT, BULLET_SPEED, COLORS, 
  BASE_PLAYER_SPEED, POWERUP_SIZE, POWERUP_SPEED, POWERUP_CHANCE,
  BOSS_WIDTH, BOSS_HEIGHT, BOSS_BASE_HEALTH
} from '../constants';
import { Alien, AlienType, Bullet, Particle, PowerUp, PowerUpType, Boss } from '../types';

interface GameCanvasProps {
  level: number;
  onGameOver: (score: number) => void;
  onVictory: (score: number) => void;
  isPaused: boolean;
  input: { left: boolean, right: boolean, fire: boolean };
}

const GameCanvas: React.FC<GameCanvasProps> = ({ level, onGameOver, onVictory, isPaused, input }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameStateRef = useRef({
    score: 0,
    highScore: parseInt(localStorage.getItem('neon_high_score') || '0'),
    playerX: CANVAS_WIDTH / 2 - PLAYER_WIDTH / 2,
    playerSpeed: BASE_PLAYER_SPEED,
    hasShield: false,
    rapidFire: false,
    bullets: [] as Bullet[],
    aliens: [] as Alien[],
    boss: null as Boss | null,
    powerUps: [] as PowerUp[],
    particles: [] as Particle[],
    alienDirection: 1,
    alienMoveTimer: 0,
    alienFireTimer: 0,
    ufoSpawnTimer: 0,
    lastFireTime: 0,
    time: 0,
    mouseFireRequested: false
  });

  const initLevel = useCallback(() => {
    const state = gameStateRef.current;
    state.bullets = [];
    state.powerUps = [];
    state.particles = [];
    state.aliens = [];
    state.boss = null;

    if (level % 3 === 0) {
      state.boss = {
        x: CANVAS_WIDTH / 2 - BOSS_WIDTH / 2,
        y: -BOSS_HEIGHT,
        width: BOSS_WIDTH,
        height: BOSS_HEIGHT,
        color: COLORS.ALIEN_BOSS,
        health: BOSS_BASE_HEALTH + (level * 10),
        maxHealth: BOSS_BASE_HEALTH + (level * 10),
        phase: 1,
        attackTimer: 0,
        direction: 1
      };
    } else {
      for (let r = 0; r < ALIEN_ROWS; r++) {
        for (let c = 0; c < ALIEN_COLS; c++) {
          let type = AlienType.GRUNT;
          let color = COLORS.ALIEN_GRUNT;
          let points = 10;
          if (r === 0) { type = AlienType.ELITE; color = COLORS.ALIEN_ELITE; points = 40; }
          else if (r === 1 || r === 2) { type = AlienType.ZIGZAG; color = COLORS.ALIEN_ZIGZAG; points = 20; }
          state.aliens.push({
            x: c * (ALIEN_SIZE + ALIEN_PADDING) + 30,
            y: r * (ALIEN_SIZE + ALIEN_PADDING) + ALIEN_OFFSET_TOP,
            width: ALIEN_SIZE, height: ALIEN_SIZE,
            color, points, alive: true, type, offsetX: 0
          });
        }
      }
    }
  }, [level]);

  useEffect(() => {
    initLevel();
  }, [initLevel]);

  // Mouse Control Listeners
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const scaleX = CANVAS_WIDTH / rect.width;
      const mouseX = (e.clientX - rect.left) * scaleX;
      // Center the ship on the mouse
      gameStateRef.current.playerX = Math.max(0, Math.min(CANVAS_WIDTH - PLAYER_WIDTH, mouseX - PLAYER_WIDTH / 2));
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) { // Left click
        gameStateRef.current.mouseFireRequested = true;
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouseFireRequested = false;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  const spawnParticles = (x: number, y: number, color: string, count = 12) => {
    for (let i = 0; i < count; i++) {
      gameStateRef.current.particles.push({
        x, y,
        width: 2 + Math.random() * 3,
        height: 2 + Math.random() * 3,
        color,
        dx: (Math.random() - 0.5) * 6,
        dy: (Math.random() - 0.5) * 6,
        life: 20 + Math.random() * 20
      });
    }
  };

  const update = useCallback(() => {
    if (isPaused) return;

    const state = gameStateRef.current;
    state.time++;

    // Player Movement (Keyboard/Button support remains)
    if (input.left && state.playerX > 0) state.playerX -= state.playerSpeed;
    if (input.right && state.playerX < CANVAS_WIDTH - PLAYER_WIDTH) state.playerX += state.playerSpeed;

    // Player Firing (Handles both Input object and direct Mouse fire request)
    const now = Date.now();
    const fireRate = state.rapidFire ? 150 : 350;
    const isFiring = input.fire || state.mouseFireRequested;
    if (isFiring && now - state.lastFireTime > fireRate) {
      state.bullets.push({
        x: state.playerX + PLAYER_WIDTH / 2 - BULLET_WIDTH / 2,
        y: CANVAS_HEIGHT - PLAYER_HEIGHT - 10,
        width: BULLET_WIDTH, height: BULLET_HEIGHT,
        color: COLORS.BULLET, dy: -BULLET_SPEED, owner: 'player'
      });
      state.lastFireTime = now;
    }

    if (state.boss) {
      const boss = state.boss;
      if (boss.y < 80) boss.y += 1;
      const healthPercent = boss.health / boss.maxHealth;
      boss.phase = healthPercent > 0.6 ? 1 : healthPercent > 0.3 ? 2 : 3;
      const bossSpeed = boss.phase === 1 ? 1.5 : boss.phase === 2 ? 2.5 : 4;
      boss.x += bossSpeed * boss.direction;
      if (boss.x + boss.width > CANVAS_WIDTH - 20 || boss.x < 20) {
        boss.direction *= -1;
        if (boss.phase === 3) boss.y += 10;
      }
      boss.attackTimer++;
      const attackFreq = boss.phase === 1 ? 80 : boss.phase === 2 ? 50 : 35;
      if (boss.attackTimer > attackFreq) {
        if (boss.phase === 1) {
          state.bullets.push({
            x: boss.x + boss.width / 2, y: boss.y + boss.height,
            width: BULLET_WIDTH, height: BULLET_HEIGHT * 1.5,
            color: boss.color, dy: BULLET_SPEED * 0.7, owner: 'alien'
          });
        } else if (boss.phase === 2) {
          [-1, 0, 1].forEach(dx => {
            state.bullets.push({
              x: boss.x + boss.width / 2, y: boss.y + boss.height,
              dx: dx * 2,
              width: BULLET_WIDTH, height: BULLET_HEIGHT,
              color: boss.color, dy: BULLET_SPEED * 0.6, owner: 'alien'
            });
          });
        } else {
          const offset = (Math.random() - 0.5) * boss.width;
          state.bullets.push({
            x: boss.x + boss.width / 2 + offset, y: boss.y + boss.height,
            width: BULLET_WIDTH * 1.5, height: BULLET_HEIGHT,
            color: COLORS.ALIEN_ZIGZAG, dy: BULLET_SPEED * 0.9, owner: 'alien'
          });
        }
        boss.attackTimer = 0;
      }
      if (boss.y + boss.height > CANVAS_HEIGHT - 100) onGameOver(state.score);
    }

    if (state.aliens.length > 0) {
      state.alienMoveTimer++;
      let edgeReached = false;
      const aliveCount = state.aliens.filter(a => a.alive).length;
      const moveThreshold = Math.max(5, 35 - (ALIEN_ROWS * ALIEN_COLS - aliveCount));
      
      if (state.alienMoveTimer > moveThreshold) {
        state.aliens.forEach(alien => {
          if (!alien.alive || alien.type === AlienType.UFO) return;
          alien.x += 10 * state.alienDirection;
          if (alien.x + alien.width > CANVAS_WIDTH - 10 || alien.x < 10) edgeReached = true;
        });
        if (edgeReached) {
          state.alienDirection *= -1;
          state.aliens.forEach(alien => {
            if (alien.type !== AlienType.UFO) alien.y += 15;
            if (alien.alive && alien.y + alien.height > CANVAS_HEIGHT - 60) onGameOver(state.score);
          });
        }
        state.alienMoveTimer = 0;
      }
      state.aliens.forEach(alien => {
        if (alien.alive && alien.type === AlienType.ZIGZAG) alien.offsetX = Math.sin(state.time / 8) * 6;
        if (alien.alive && alien.type === AlienType.UFO) {
          alien.x += 3.5;
          if (alien.x > CANVAS_WIDTH + 50) alien.alive = false;
        }
      });
    }

    state.ufoSpawnTimer++;
    if (state.ufoSpawnTimer > 1200) {
      state.aliens.push({
        x: -50, y: 50, width: 40, height: 20,
        color: COLORS.ALIEN_UFO, points: 200 + Math.floor(Math.random() * 300),
        alive: true, type: AlienType.UFO
      });
      state.ufoSpawnTimer = 0;
    }

    // Balanced Alien Firing Logic
    if (state.aliens.length > 0 && !state.boss) {
      state.alienFireTimer++;
      const aliveSwarm = state.aliens.filter(a => a.alive && a.type !== AlienType.UFO);
      if (aliveSwarm.length > 0) {
        // Threshold drops (faster firing) as level increases and as fewer aliens remain
        const levelBonus = (level - 1) * 3;
        const countBonus = (ALIEN_ROWS * ALIEN_COLS - aliveSwarm.length) * 0.5;
        const fireThreshold = Math.max(15, 70 - levelBonus - countBonus);

        if (state.alienFireTimer > fireThreshold) {
          // Classic Invaders: Only the bottom-most alien in each column fires
          const columnBottoms = new Map<number, Alien>();
          aliveSwarm.forEach(alien => {
            const colKey = Math.round(alien.x / 10) * 10;
            const existing = columnBottoms.get(colKey);
            if (!existing || alien.y > existing.y) {
              columnBottoms.set(colKey, alien);
            }
          });

          const candidates = Array.from(columnBottoms.values());
          if (candidates.length > 0) {
            const shooter = candidates[Math.floor(Math.random() * candidates.length)];
            state.bullets.push({
              x: shooter.x + (shooter.offsetX || 0) + shooter.width / 2 - BULLET_WIDTH / 2,
              y: shooter.y + shooter.height,
              width: BULLET_WIDTH, 
              height: BULLET_HEIGHT,
              color: shooter.color, 
              dy: BULLET_SPEED * (0.4 + (level * 0.04)), // Bullet speed scales slightly with level
              owner: 'alien'
            });
          }
          state.alienFireTimer = 0;
        }
      }
    }

    state.powerUps = state.powerUps.filter(pu => {
      pu.y += pu.dy;
      if (pu.x < state.playerX + PLAYER_WIDTH && pu.x + pu.width > state.playerX &&
          pu.y < CANVAS_HEIGHT - 10 && pu.y + pu.height > CANVAS_HEIGHT - PLAYER_HEIGHT - 10) {
        if (pu.type === PowerUpType.RAPID_FIRE) { state.rapidFire = true; setTimeout(() => state.rapidFire = false, 5000); }
        else if (pu.type === PowerUpType.SPEED_BOOST) { state.playerSpeed = BASE_PLAYER_SPEED * 1.8; setTimeout(() => state.playerSpeed = BASE_PLAYER_SPEED, 5000); }
        else if (pu.type === PowerUpType.SHIELD) { state.hasShield = true; }
        return false;
      }
      return pu.y < CANVAS_HEIGHT;
    });

    state.bullets = state.bullets.filter(bullet => {
      bullet.y += bullet.dy;
      if (bullet.dx) bullet.x += bullet.dx;
      
      if (bullet.owner === 'player') {
        if (state.boss) {
          const boss = state.boss;
          if (bullet.x < boss.x + boss.width && bullet.x + bullet.width > boss.x &&
              bullet.y < boss.y + boss.height && bullet.y + bullet.height > boss.y) {
            boss.health -= 1;
            spawnParticles(bullet.x, bullet.y, boss.color, 4);
            if (boss.health <= 0) {
              state.score += 5000;
              spawnParticles(boss.x + boss.width/2, boss.y + boss.height/2, boss.color, 50);
              onVictory(state.score);
              state.boss = null;
            }
            return false;
          }
        }
        for (const alien of state.aliens) {
          const ax = alien.x + (alien.offsetX || 0);
          if (alien.alive && bullet.x < ax + alien.width && bullet.x + bullet.width > ax &&
              bullet.y < alien.y + alien.height && bullet.y + bullet.height > alien.y) {
            alien.alive = false;
            state.score += alien.points;
            if (state.score > state.highScore) { state.highScore = state.score; localStorage.setItem('neon_high_score', state.highScore.toString()); }
            spawnParticles(ax + alien.width/2, alien.y + alien.height/2, alien.color);
            if (Math.random() < POWERUP_CHANCE) {
              const types = [PowerUpType.RAPID_FIRE, PowerUpType.SPEED_BOOST, PowerUpType.SHIELD];
              const pType = types[Math.floor(Math.random() * types.length)];
              state.powerUps.push({
                x: ax + alien.width/2 - POWERUP_SIZE/2, y: alien.y,
                width: POWERUP_SIZE, height: POWERUP_SIZE,
                color: pType === PowerUpType.RAPID_FIRE ? COLORS.POWERUP_RF : pType === PowerUpType.SPEED_BOOST ? COLORS.POWERUP_SB : COLORS.POWERUP_SH,
                type: pType, dy: POWERUP_SPEED
              });
            }
            return false;
          }
        }
      } else {
        if (bullet.x < state.playerX + PLAYER_WIDTH && bullet.x + bullet.width > state.playerX &&
            bullet.y < CANVAS_HEIGHT - 10 && bullet.y + bullet.height > CANVAS_HEIGHT - PLAYER_HEIGHT - 10) {
          if (state.hasShield) { state.hasShield = false; spawnParticles(state.playerX + PLAYER_WIDTH/2, CANVAS_HEIGHT - 20, COLORS.SHIELD); return false; }
          else { onGameOver(state.score); return false; }
        }
      }
      return bullet.y > 0 && bullet.y < CANVAS_HEIGHT && bullet.x > 0 && bullet.x < CANVAS_WIDTH;
    });

    state.particles = state.particles.filter(p => { p.x += p.dx; p.y += p.dy; p.life--; return p.life > 0; });

    if (!state.boss && state.aliens.length > 0 && state.aliens.every(a => !a.alive || a.type === AlienType.UFO)) {
      onVictory(state.score);
    }

  }, [input, isPaused, onGameOver, onVictory, level]);

  const draw = useCallback((ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    const state = gameStateRef.current;

    ctx.fillStyle = COLORS.PLAYER;
    ctx.shadowBlur = 10; ctx.shadowColor = COLORS.PLAYER;
    ctx.beginPath();
    ctx.moveTo(state.playerX + PLAYER_WIDTH / 2, CANVAS_HEIGHT - 35);
    ctx.lineTo(state.playerX, CANVAS_HEIGHT - 15);
    ctx.lineTo(state.playerX + PLAYER_WIDTH, CANVAS_HEIGHT - 15);
    ctx.closePath();
    ctx.fill();

    if (state.hasShield) {
      ctx.strokeStyle = COLORS.SHIELD; ctx.lineWidth = 2; ctx.shadowColor = COLORS.SHIELD;
      ctx.beginPath(); ctx.arc(state.playerX + PLAYER_WIDTH/2, CANVAS_HEIGHT - 20, PLAYER_WIDTH * 0.8, 0, Math.PI, true); ctx.stroke();
    }

    if (state.boss) {
      const boss = state.boss;
      ctx.fillStyle = boss.color; ctx.shadowColor = boss.color; ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.ellipse(boss.x + boss.width/2, boss.y + boss.height/2, boss.width/2, boss.height/2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = COLORS.BOSS_EYE;
      const eyeSize = 15;
      const eyeY = boss.y + boss.height/3;
      if (boss.phase === 1) { ctx.fillRect(boss.x + boss.width/2 - eyeSize/2, eyeY, eyeSize, eyeSize); }
      else if (boss.phase === 2) { ctx.fillRect(boss.x + boss.width/4, eyeY, eyeSize, eyeSize); ctx.fillRect(boss.x + 3*boss.width/4 - eyeSize, eyeY, eyeSize, eyeSize); }
      else { ctx.fillStyle = COLORS.ALIEN_ZIGZAG; for (let i = 0; i < 4; i++) { ctx.fillRect(boss.x + (i+0.5) * boss.width/4 - 5, eyeY, 10, 10); } }
      const barW = 200;
      const barH = 6;
      const barX = (CANVAS_WIDTH - barW) / 2;
      const barY = 15;
      ctx.fillStyle = '#333'; ctx.shadowBlur = 0; ctx.fillRect(barX, barY, barW, barH);
      ctx.fillStyle = boss.color; ctx.fillRect(barX, barY, barW * (boss.health / boss.maxHealth), barH);
      ctx.strokeStyle = '#fff'; ctx.strokeRect(barX, barY, barW, barH);
    }

    state.aliens.forEach(alien => {
      if (!alien.alive) return;
      const ax = alien.x + (alien.offsetX || 0);
      ctx.fillStyle = alien.color; ctx.shadowColor = alien.color; ctx.shadowBlur = 8;
      if (alien.type === AlienType.UFO) {
        ctx.beginPath(); ctx.ellipse(ax + alien.width/2, alien.y + alien.height/2, alien.width/2, alien.height/2, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(ax + 10, alien.y + 8, 5, 4); ctx.fillRect(ax + 25, alien.y + 8, 5, 4);
      } else {
        ctx.fillRect(ax + 4, alien.y + 4, alien.width - 8, alien.height - 8);
        if (alien.type === AlienType.ELITE) { ctx.fillRect(ax, alien.y + 12, alien.width, 3); ctx.fillRect(ax + 8, alien.y, 12, 4); }
        else if (alien.type === AlienType.ZIGZAG) { ctx.fillRect(ax, alien.y + 6, alien.width, 10); }
        else { ctx.fillRect(ax, alien.y + 10, alien.width, 5); }
      }
    });

    state.powerUps.forEach(pu => {
      ctx.shadowColor = pu.color; ctx.shadowBlur = 15; ctx.fillStyle = pu.color;
      ctx.beginPath(); ctx.moveTo(pu.x + pu.width/2, pu.y); ctx.lineTo(pu.x + pu.width, pu.y + pu.height/2); ctx.lineTo(pu.x + pu.width/2, pu.y + pu.height); ctx.lineTo(pu.x, pu.y + pu.height/2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.font = 'bold 10px Arial';
      const label = pu.type === PowerUpType.RAPID_FIRE ? 'R' : pu.type === PowerUpType.SPEED_BOOST ? 'S' : 'B';
      ctx.fillText(label, pu.x + 6, pu.y + 14);
    });
    state.bullets.forEach(b => { ctx.fillStyle = b.color; ctx.shadowColor = b.color; ctx.fillRect(b.x, b.y, b.width, b.height); });
    state.particles.forEach(p => { ctx.globalAlpha = p.life / 40; ctx.fillStyle = p.color; ctx.fillRect(p.x, p.y, p.width, p.height); });
    ctx.globalAlpha = 1; ctx.shadowBlur = 0;

    ctx.fillStyle = COLORS.TEXT; ctx.font = '10px "Press Start 2P"';
    ctx.fillText(`SCORE: ${state.score.toString().padStart(5, '0')}`, 10, 25);
    ctx.fillText(`HI: ${state.highScore.toString().padStart(5, '0')}`, 10, 45);
    if (state.rapidFire) { ctx.fillStyle = COLORS.POWERUP_RF; ctx.fillText("RAPID FIRE", 260, 25); }
    if (state.playerSpeed > BASE_PLAYER_SPEED) { ctx.fillStyle = COLORS.POWERUP_SB; ctx.fillText("SPEED UP", 260, 45); }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animationId: number;
    const render = () => { update(); draw(ctx); animationId = requestAnimationFrame(render); };
    render();
    return () => cancelAnimationFrame(animationId);
  }, [update, draw]);

  return (
    <div className="relative flex justify-center items-center h-full w-full">
      <canvas 
        ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT}
        className="bg-black border-2 border-cyan-500/30 rounded-lg shadow-[0_0_20px_rgba(0,255,204,0.2)] cursor-none"
        style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
      />
    </div>
  );
};

export default GameCanvas;
