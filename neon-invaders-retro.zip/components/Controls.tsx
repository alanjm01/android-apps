
import React from 'react';

interface ControlsProps {
  onInput: (key: string, pressed: boolean) => void;
}

const Controls: React.FC<ControlsProps> = ({ onInput }) => {
  return (
    <div className="fixed bottom-0 left-0 w-full p-6 flex justify-between items-end pointer-events-none select-none z-[110]">
      <div className="flex gap-4 pointer-events-auto">
        <button 
          onMouseDown={() => onInput('left', true)}
          onMouseUp={() => onInput('left', false)}
          onTouchStart={(e) => { e.preventDefault(); onInput('left', true); }}
          onTouchEnd={(e) => { e.preventDefault(); onInput('left', false); }}
          className="w-20 h-20 bg-cyan-900/40 border-2 border-cyan-500 rounded-full flex items-center justify-center active:bg-cyan-500/60 shadow-[0_0_15px_rgba(0,255,255,0.3)]"
        >
          <svg className="w-10 h-10 text-cyan-400" fill="currentColor" viewBox="0 0 24 24">
            <path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/>
          </svg>
        </button>
        <button 
          onMouseDown={() => onInput('right', true)}
          onMouseUp={() => onInput('right', false)}
          onTouchStart={(e) => { e.preventDefault(); onInput('right', true); }}
          onTouchEnd={(e) => { e.preventDefault(); onInput('right', false); }}
          className="w-20 h-20 bg-cyan-900/40 border-2 border-cyan-500 rounded-full flex items-center justify-center active:bg-cyan-500/60 shadow-[0_0_15px_rgba(0,255,255,0.3)]"
        >
          <svg className="w-10 h-10 text-cyan-400" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/>
          </svg>
        </button>
      </div>
      
      <div className="pointer-events-auto">
        <button 
          onMouseDown={() => onInput('fire', true)}
          onMouseUp={() => onInput('fire', false)}
          onTouchStart={(e) => { e.preventDefault(); onInput('fire', true); }}
          onTouchEnd={(e) => { e.preventDefault(); onInput('fire', false); }}
          className="w-24 h-24 bg-red-900/40 border-4 border-red-500 rounded-full flex items-center justify-center active:bg-red-500/60 shadow-[0_0_25px_rgba(255,0,0,0.4)] uppercase text-red-500 font-bold tracking-tighter"
        >
          FIRE
        </button>
      </div>
    </div>
  );
};

export default Controls;
