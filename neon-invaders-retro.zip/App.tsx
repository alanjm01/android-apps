
import React, { useState, useEffect, useCallback } from 'react';
import GameCanvas from './components/GameCanvas';
import Controls from './components/Controls';
import { GameState, Briefing } from './types';
import { getMissionBriefing } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(parseInt(localStorage.getItem('neon_high_score') || '0'));
  const [briefing, setBriefing] = useState<Briefing | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [input, setInput] = useState({ left: false, right: false, fire: false });
  const [showHowTo, setShowHowTo] = useState(false);

  useEffect(() => {
    setHighScore(parseInt(localStorage.getItem('neon_high_score') || '0'));
  }, [gameState]);

  const handleInput = useCallback((key: string, pressed: boolean) => {
    setInput(prev => ({ ...prev, [key]: pressed }));
  }, []);

  const startGame = async () => {
    setIsLoading(true);
    const data = await getMissionBriefing(level);
    setBriefing(data);
    setGameState(GameState.BRIEFING);
    setIsLoading(false);
  };

  const handleGameOver = (finalScore: number) => {
    setScore(finalScore);
    setGameState(GameState.GAME_OVER);
  };

  const handleVictory = (finalScore: number) => {
    setScore(finalScore);
    setGameState(GameState.VICTORY);
  };

  const nextLevel = async () => {
    const nextLvl = level + 1;
    setLevel(nextLvl);
    setIsLoading(true);
    const data = await getMissionBriefing(nextLvl);
    setBriefing(data);
    setGameState(GameState.BRIEFING);
    setIsLoading(false);
  };

  const resetGame = () => {
    setLevel(1);
    setScore(0);
    setGameState(GameState.START);
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-cyan-400">
      {/* Game Engine */}
      {gameState === GameState.PLAYING && (
        <>
          <GameCanvas 
            level={level}
            onGameOver={handleGameOver} 
            onVictory={handleVictory} 
            isPaused={false}
            input={input}
          />
          <Controls onInput={handleInput} />
        </>
      )}

      {/* Overlays */}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center z-[150]">
        
        {gameState === GameState.START && (
          <div className="space-y-8 flicker max-w-lg w-full">
            {!showHowTo ? (
              <>
                <div className="text-cyan-500/80 text-sm tracking-widest uppercase mb-2">HI-SCORE: {highScore.toString().padStart(5, '0')}</div>
                <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-cyan-400 to-blue-600 drop-shadow-[0_0_20px_rgba(0,255,255,0.8)]">
                  NEON<br/>INVADERS
                </h1>
                <div className="flex flex-col gap-4 items-center">
                  <button 
                    onClick={startGame}
                    disabled={isLoading}
                    className="w-64 py-4 bg-cyan-900/40 border-2 border-cyan-500 rounded text-xl hover:bg-cyan-500/20 active:scale-95 transition-all shadow-[0_0_20px_rgba(0,255,255,0.3)]"
                  >
                    {isLoading ? 'INITIATING...' : 'INSERT COIN'}
                  </button>
                  <button 
                    onClick={() => setShowHowTo(true)}
                    className="w-64 py-2 text-sm border border-cyan-900 text-cyan-700 hover:text-cyan-400 hover:border-cyan-400 transition-colors uppercase tracking-widest"
                  >
                    HOW TO PLAY
                  </button>
                </div>
              </>
            ) : (
              <div className="bg-black/90 border-2 border-cyan-500 p-8 rounded-lg shadow-[0_0_30px_rgba(0,255,255,0.2)] text-left space-y-4">
                <h2 className="text-xl text-cyan-400 mb-4 text-center">PILOT MANUAL</h2>
                <div className="space-y-4 text-xs md:text-sm leading-relaxed">
                  <div>
                    <span className="text-cyan-200">DESKTOP:</span> Move mouse to guide ship. Left-Click to fire.
                  </div>
                  <div>
                    <span className="text-cyan-200">MOBILE:</span> Use on-screen pads to move. Red button to fire.
                  </div>
                  <div className="h-px bg-cyan-900/50 my-2" />
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="text-red-500">[R] RAPID FIRE</div>
                    <div className="text-blue-500">[S] SPEED BOOST</div>
                    <div className="text-green-500">[B] SHIELD</div>
                    <div className="text-purple-500">[UFO] BONUS PTS</div>
                  </div>
                </div>
                <button 
                  onClick={() => setShowHowTo(false)}
                  className="w-full mt-6 py-2 bg-cyan-500/20 border border-cyan-500 hover:bg-cyan-500/40"
                >
                  BACK
                </button>
              </div>
            )}
            <p className="text-xs text-cyan-500/60 animate-pulse">© 2024 RETRO SYSTEM OS</p>
          </div>
        )}

        {gameState === GameState.BRIEFING && briefing && (
          <div className="max-w-md w-full bg-black/80 border-2 border-cyan-500 p-8 rounded-lg shadow-[0_0_50px_rgba(0,255,255,0.2)] space-y-6">
            <div className="text-red-500 text-sm mb-4 tracking-[0.2em]">INCOMING TRANSMISSION</div>
            <h2 className="text-xl text-cyan-400 uppercase leading-relaxed">{briefing.title}</h2>
            <div className="h-px bg-cyan-900 w-full" />
            <p className="text-sm leading-loose text-left font-mono whitespace-pre-wrap">
              {briefing.message}
            </p>
            <button 
              onClick={() => setGameState(GameState.PLAYING)}
              className="w-full py-4 bg-red-600/20 border border-red-500 text-red-500 hover:bg-red-500/40 transition-colors"
            >
              ENGAGE
            </button>
          </div>
        )}

        {gameState === GameState.GAME_OVER && (
          <div className="space-y-8 flicker">
            <h2 className="text-5xl text-red-500 font-black drop-shadow-[0_0_15px_rgba(255,0,0,0.8)]">GAME OVER</h2>
            <div className="text-2xl">FINAL SCORE: {score}</div>
            <div className="text-sm text-red-400/60 uppercase tracking-widest">Hi-Score: {highScore}</div>
            <button 
              onClick={resetGame}
              className="px-8 py-4 bg-red-900/40 border-2 border-red-500 rounded text-xl"
            >
              RETRY?
            </button>
          </div>
        )}

        {gameState === GameState.VICTORY && (
          <div className="space-y-8">
            <h2 className="text-5xl text-green-400 font-black drop-shadow-[0_0_15px_rgba(0,255,0,0.8)]">VICTORY</h2>
            <div className="text-2xl">SCORE: {score}</div>
            <button 
              onClick={nextLevel}
              disabled={isLoading}
              className="px-8 py-4 bg-green-900/40 border-2 border-green-500 rounded text-xl"
            >
              {isLoading ? 'ANALYZING...' : 'NEXT SECTOR'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
