
import { GoogleGenAI, Type } from "@google/genai";
import { Briefing } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMissionBriefing = async (level: number): Promise<Briefing> => {
  const isBossLevel = level % 3 === 0;
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a retro sci-fi mission briefing for level ${level} of an arcade shooter. 
      ${isBossLevel ? 'This is a BOSS LEVEL. A massive Mothership has been detected.' : 'Standard sector sweep.'}
      The tone should be dramatic, 80s arcade inspired, and urgent. 
      Keep the message under 150 characters.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "A catchy mission title" },
            message: { type: Type.STRING, description: "The briefing text" }
          },
          required: ["title", "message"]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    return {
      title: data.title || (isBossLevel ? "BOSS THREAT DETECTED" : `SECTOR ${level} BREACHED`),
      message: data.message || (isBossLevel ? "A colossal Mothership is entering the atmosphere. Brace for maximum resistance!" : `The alien swarm is approaching. Defend the perimeter!`)
    };
  } catch (error) {
    console.error("Gemini Briefing Error:", error);
    return {
      title: isBossLevel ? "ULTIMATE THREAT" : `LEVEL ${level}`,
      message: isBossLevel ? "Warning: Colossal signature detected. Good luck, pilot." : `Enemies detected. Prepare for engagement.`
    };
  }
};
