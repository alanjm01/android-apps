
import React, { useState, useEffect, useCallback, useRef } from 'react';
import PongCanvas from './components/PongCanvas';
import RetroOverlay from './components/RetroOverlay';
import GeminiChat from './components/GeminiChat';
import { GameStatus, Comment, Difficulty } from './types';
import { getGameCommentary } from './services/geminiService';
import { audioService } from './services/audioService';

const App: React.FC = () => {
  const [status, setStatus] = useState<GameStatus>(GameStatus.MENU);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.MEDIUM);
  const [scores, setScores] = useState({ player: 0, ai: 0 });
  const [level, setLevel] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [comments, setComments] = useState<Comment[]>([
    { text: "WELCOME TO THE NEON RIFT.", sender: 'System', timestamp: Date.now() }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const addComment = useCallback((text: string, sender: 'Gemini' | 'System' = 'Gemini') => {
    setComments(prev => [...prev.slice(-4), { text, sender, timestamp: Date.now() }]);
  }, []);

  const toggleMute = () => {
    const newVal = !isMuted;
    setIsMuted(newVal);
    audioService.setMuted(newVal);
  };

  const handlePointScored = useCallback(async (winner: 'player' | 'ai') => {
    if (winner === 'player') audioService.playScorePlayer();
    else audioService.playScoreAI();

    setScores(prev => {
      const newScores = {
        ...prev,
        [winner]: prev[winner] + 1
      };
      
      // Level progression: increase level every 3 player points
      if (winner === 'player' && newScores.player % 3 === 0 && newScores.player < 11) {
        setLevel(l => l + 1);
        addComment(`SYSTEM ALERT: ESCALATING TO LEVEL ${Math.floor(newScores.player / 3) + 1}.`, 'System');
      }

      // Winning condition: 11 points
      if (newScores.player >= 11 || newScores.ai >= 11) {
        setTimeout(() => {
          setStatus(GameStatus.GAMEOVER);
          audioService.playGameOver();
        }, 500);
      }
      
      return newScores;
    });

    setIsAiLoading(true);
    const event = winner === 'player' ? "Player scored a point!" : "AI scored a point!";
    const commentary = await getGameCommentary(
      winner === 'player' ? scores.player + 1 : scores.player,
      winner === 'ai' ? scores.ai + 1 : scores.ai,
      event
    );
    addComment(commentary);
    setIsAiLoading(false);
  }, [scores, addComment]);

  const startGame = () => {
    setScores({ player: 0, ai: 0 });
    setLevel(1);
    setStatus(GameStatus.PLAYING);
    addComment(`GAME INITIALIZED ON ${difficulty} MODE.`, 'System');
    
    // Initialize Audio & BGM on first interaction
    audioService.startBGM();
    audioService.playWallBounce(); 
  };

  const difficultyColors = {
    [Difficulty.EASY]: 'border-green-400 text-green-400',
    [Difficulty.MEDIUM]: 'border-yellow-400 text-yellow-400',
    [Difficulty.HARD]: 'border-red-500 text-red-500'
  };

  return (
    <div className="relative w-screen h-screen bg-black overflow-hidden flex flex-col items-center justify-center select-none">
      <RetroOverlay />
      
      {/* HUD / Header */}
      <div className="absolute top-8 left-0 w-full flex justify-between items-start px-12 z-20">
        <div className="flex flex-col items-start">
          <div className="text-xl md:text-2xl neon-text text-cyan-400 pointer-events-none">P1: {scores.player}</div>
          <div className="text-[10px] text-cyan-400/60 mt-1 uppercase">User_ID: NeonRider</div>
        </div>
        
        <div className="flex flex-col items-center">
           <div className="text-sm md:text-xl text-white neon-text mb-2 tracking-widest">LEVEL {level}</div>
           <button 
            onClick={toggleMute}
            className="bg-transparent border border-cyan-400/30 p-2 text-cyan-400 hover:bg-cyan-400/10 transition-all pointer-events-auto rounded shadow-[0_0_10px_rgba(0,255,204,0.1)]"
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? '🔇' : '🔊'}
          </button>
        </div>

        <div className="flex flex-col items-end">
          <div className="text-xl md:text-2xl neon-text text-pink-500 pointer-events-none">CPU: {scores.ai}</div>
          <div className="text-[10px] text-pink-500/60 mt-1 uppercase">Target: NEON-X</div>
        </div>
      </div>

      {/* Main Game Area */}
      <div className="relative w-full h-full flex items-center justify-center">
        {status === GameStatus.MENU && (
          <div className="z-30 flex flex-col items-center space-y-8">
            <h1 className="text-4xl md:text-6xl text-cyan-400 neon-text text-center px-4 animate-pulse">NEON RIFT PONG</h1>
            
            <div className="flex flex-col items-center space-y-4">
              <span className="text-xs text-cyan-400 tracking-widest uppercase">Select Difficulty</span>
              <div className="flex space-x-2">
                {Object.values(Difficulty).map((levelOpt) => (
                  <button
                    key={levelOpt}
                    onClick={() => setDifficulty(levelOpt)}
                    className={`px-3 py-2 border-2 text-[10px] transition-all uppercase ${
                      difficulty === levelOpt 
                        ? `${difficultyColors[levelOpt]} bg-current/10 scale-110 shadow-[0_0_10px_rgba(255,255,255,0.3)]` 
                        : 'border-gray-700 text-gray-700 hover:border-gray-500 hover:text-gray-500'
                    }`}
                  >
                    {levelOpt}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={startGame}
              className="px-8 py-4 bg-transparent border-4 border-cyan-400 text-cyan-400 text-xl md:text-2xl hover:bg-cyan-400 hover:text-black transition-all cursor-pointer neon-border"
            >
              START GAME
            </button>
            <p className="text-xs text-gray-400 text-center max-w-xs uppercase leading-loose">
              Mobile: Touch & Slide<br/>
              Desktop: Mouse or Keys
            </p>
          </div>
        )}

        {status === GameStatus.PLAYING && (
          <PongCanvas 
            difficulty={difficulty}
            level={level}
            onScore={handlePointScored} 
            onGameOver={() => setStatus(GameStatus.GAMEOVER)}
          />
        )}

        {status === GameStatus.GAMEOVER && (
          <div className="z-30 flex flex-col items-center space-y-6">
            <h2 className="text-5xl text-pink-500 neon-text">GAME OVER</h2>
            <div className="text-xl text-white uppercase tracking-widest">BASE: {difficulty} | REACHED LVL {level}</div>
            <div className="text-xl text-white uppercase">Result: {scores.player > scores.ai ? 'Victory' : 'Defeat'}</div>
            <div className="text-xl text-white">SCORE: {scores.player} - {scores.ai}</div>
            
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              <button 
                onClick={startGame}
                className="px-8 py-4 bg-transparent border-4 border-cyan-400 text-cyan-400 text-xl hover:scale-105 transition-transform cursor-pointer shadow-[0_0_20px_rgba(0,255,204,0.3)] uppercase"
              >
                Restart Game
              </button>
              <button 
                onClick={() => setStatus(GameStatus.MENU)}
                className="px-8 py-4 bg-pink-600 text-white text-xl hover:scale-105 transition-transform cursor-pointer shadow-[0_0_20px_rgba(219,39,119,0.5)] uppercase"
              >
                Main Menu
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Gemini Commentator Box */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-full max-w-md px-4 z-20">
        <GeminiChat comments={comments} isLoading={isAiLoading} />
      </div>
    </div>
  );
};

export default App;
