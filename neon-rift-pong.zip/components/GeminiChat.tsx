
import React, { useEffect, useRef } from 'react';
import { Comment } from '../types';

interface GeminiChatProps {
  comments: Comment[];
  isLoading: boolean;
}

const GeminiChat: React.FC<GeminiChatProps> = ({ comments, isLoading }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [comments]);

  return (
    <div className="bg-black/80 border-t-2 border-cyan-400 p-3 h-32 flex flex-col font-mono text-[10px] md:text-xs overflow-hidden shadow-[0_-10px_20px_rgba(0,255,204,0.1)]">
      <div className="flex justify-between items-center mb-1 border-b border-cyan-900 pb-1">
        <span className="text-cyan-400 uppercase">Commentary Log</span>
        {isLoading && <span className="animate-pulse text-pink-500">NEON-X IS THINKING...</span>}
      </div>
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-2 scrollbar-hide"
      >
        {comments.map((c, i) => (
          <div key={i} className="flex space-x-2 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <span className={c.sender === 'Gemini' ? "text-pink-500 font-bold" : "text-gray-500"}>
              [{c.sender === 'Gemini' ? "NEON-X" : "SYS"}]:
            </span>
            <span className="text-cyan-100 uppercase tracking-tighter">{c.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GeminiChat;
