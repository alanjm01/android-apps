
import React, { useEffect, useRef, useCallback } from 'react';
import { Ball, Paddle, Difficulty } from '../types';
import { audioService } from '../services/audioService';

interface PongCanvasProps {
  difficulty: Difficulty;
  level: number;
  onScore: (winner: 'player' | 'ai') => void;
  onGameOver: () => void;
}

const PADDLE_WIDTH = 15;
const PADDLE_HEIGHT = 80;
const BALL_SIZE = 10;
const INITIAL_SPEED_BASE = 9;

const PongCanvas: React.FC<PongCanvasProps> = ({ difficulty, level, onScore, onGameOver }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();

  const getSpeedMultiplier = useCallback((diff: Difficulty) => {
    switch (diff) {
      case Difficulty.EASY: return 0.7;
      case Difficulty.HARD: return 2.0; // Double the speed on hard level
      case Difficulty.MEDIUM:
      default: return 1.0;
    }
  }, []);

  const speedMult = getSpeedMultiplier(difficulty);
  
  // Game State Refs
  const ball = useRef<Ball>({
    x: 0, y: 0, width: BALL_SIZE, height: BALL_SIZE, color: '#fff',
    dx: INITIAL_SPEED_BASE * speedMult, 
    dy: INITIAL_SPEED_BASE * speedMult, 
    speed: INITIAL_SPEED_BASE * speedMult, 
    radius: BALL_SIZE / 2
  });

  const player = useRef<Paddle>({
    x: 20, y: 0, width: PADDLE_WIDTH, height: PADDLE_HEIGHT, color: '#00ffcc',
    score: 0, 
    speed: difficulty === Difficulty.HARD ? 40 : 20 // Responsive paddle for high speeds
  });

  // Animation intensities (0 to 1)
  const playerHitIntensity = useRef(0);
  const aiHitIntensity = useRef(0);

  // Difficulty multiplier logic - now factors in 'level' and 'speedMult'
  const getAiSettings = useCallback((diff: Difficulty, lvl: number) => {
    let baseSpeed = 7.0;
    let baseError = 15;

    switch (diff) {
      case Difficulty.EASY:
        baseSpeed = 5.0;
        baseError = 40;
        break;
      case Difficulty.HARD:
        baseSpeed = 15.0; // Doubled relative to a fast baseline
        baseError = 0;
        break;
      case Difficulty.MEDIUM:
      default:
        baseSpeed = 7.0;
        baseError = 15;
        break;
    }

    const multiplier = getSpeedMultiplier(diff);

    return {
      speed: (baseSpeed + (lvl - 1) * 1.0) * (diff === Difficulty.HARD ? 1 : 1), // logic already factored in hard baseSpeed
      errorMargin: Math.max(0, baseError - (lvl - 1) * 5)
    };
  }, [getSpeedMultiplier]);

  const aiSettings = useRef(getAiSettings(difficulty, level));

  useEffect(() => {
    aiSettings.current = getAiSettings(difficulty, level);
  }, [difficulty, level, getAiSettings]);

  const ai = useRef<Paddle>({
    x: 0, y: 0, width: PADDLE_WIDTH, height: PADDLE_HEIGHT, color: '#ff00ff',
    score: 0, speed: aiSettings.current.speed
  });

  const aiOffset = useRef(0);

  const getAiColorForSpeed = (speed: number) => {
    const baseLine = INITIAL_SPEED_BASE * speedMult;
    const speedFactor = Math.min(1, (speed - baseLine) / (15 * speedMult));
    const hue = 300 - (speedFactor * 300);
    const lightness = 50 + (speedFactor * 25);
    return `hsl(${hue}, 100%, ${lightness}%)`;
  };

  const resetBall = (direction: 1 | -1) => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    const currentInitialSpeed = (INITIAL_SPEED_BASE + (level - 1) * 1.0) * speedMult;
    
    ball.current.x = canvas.width / 2;
    ball.current.y = canvas.height / 2;
    ball.current.speed = currentInitialSpeed;
    ball.current.dx = currentInitialSpeed * direction;
    ball.current.dy = (Math.random() - 0.5) * currentInitialSpeed * 2;
    
    aiOffset.current = (Math.random() - 0.5) * aiSettings.current.errorMargin * 2;
  };

  const update = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;

    // Ball movement
    ball.current.x += ball.current.dx;
    ball.current.y += ball.current.dy;

    // Update AI Color based on ball speed
    ai.current.color = getAiColorForSpeed(ball.current.speed);

    // AI logic
    const shouldMove = difficulty === Difficulty.HARD || ball.current.dx > 0 || ball.current.x > canvas.width / 2;
    if (shouldMove) {
      const currentAiSpeed = aiSettings.current.speed;
      const aiTarget = ball.current.y - (ai.current.height / 2) + aiOffset.current;
      if (Math.abs(ai.current.y - aiTarget) > currentAiSpeed) {
        if (ai.current.y < aiTarget) ai.current.y += currentAiSpeed;
        else if (ai.current.y > aiTarget) ai.current.y -= currentAiSpeed;
      }
    }

    // Wall collision
    if (ball.current.y <= 0 || ball.current.y + ball.current.height >= canvas.height) {
      ball.current.dy *= -1;
      audioService.playWallBounce();
    }

    // Goal detection
    if (ball.current.x < 0) {
      onScore('ai');
      resetBall(1);
    } else if (ball.current.x > canvas.width) {
      onScore('player');
      resetBall(-1);
    }

    // Paddle Collisions
    const checkCollision = (b: Ball, p: Paddle) => {
      return b.x < p.x + p.width &&
             b.x + b.width > p.x &&
             b.y < p.y + p.height &&
             b.y + b.height > p.y;
    };

    let p = (ball.current.x < canvas.width / 2) ? player.current : ai.current;
    if (checkCollision(ball.current, p)) {
      audioService.playPaddleHit();
      
      if (p === player.current) playerHitIntensity.current = 1.0;
      else aiHitIntensity.current = 1.0;

      let collidePoint = ball.current.y + (ball.current.height / 2);
      collidePoint = collidePoint - (p.y + (p.height / 2));
      collidePoint = collidePoint / (p.height / 2);

      let angleRad = collidePoint * (Math.PI / 4);
      let direction = (ball.current.x < canvas.width / 2) ? 1 : -1;
      
      ball.current.dx = direction * ball.current.speed * Math.cos(angleRad);
      ball.current.dy = ball.current.speed * Math.sin(angleRad);
      
      ball.current.speed += (0.6 + (level - 1) * 0.15) * speedMult;

      if (p === player.current) {
        aiOffset.current = (Math.random() - 0.5) * aiSettings.current.errorMargin * 2;
      }
    }

    // Update animations
    playerHitIntensity.current = Math.max(0, playerHitIntensity.current * 0.85 - 0.01);
    aiHitIntensity.current = Math.max(0, aiHitIntensity.current * 0.85 - 0.01);

    // Boundaries
    player.current.y = Math.max(0, Math.min(canvas.height - player.current.height, player.current.y));
    ai.current.y = Math.max(0, Math.min(canvas.height - ai.current.height, ai.current.y));
  };

  const drawPaddle = (ctx: CanvasRenderingContext2D, p: Paddle, intensity: number) => {
    ctx.save();
    
    if (intensity > 0) {
      const scale = 1 + intensity * 0.15;
      ctx.translate(p.x + p.width / 2, p.y + p.height / 2);
      ctx.scale(scale, scale);
      ctx.translate(-(p.x + p.width / 2), -(p.y + p.height / 2));
    }

    ctx.shadowBlur = 15;
    ctx.shadowColor = p.color;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.width, p.height);

    if (intensity > 0) {
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#fff';
      ctx.fillStyle = `rgba(255, 255, 255, ${intensity})`;
      ctx.fillRect(p.x, p.y, p.width, p.height);
    }

    ctx.restore();
  };

  const draw = (ctx: CanvasRenderingContext2D) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Net
    ctx.strokeStyle = '#222';
    ctx.setLineDash([10, 10]);
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 0);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw Paddles with animations
    drawPaddle(ctx, player.current, playerHitIntensity.current);
    drawPaddle(ctx, ai.current, aiHitIntensity.current);

    // Draw Ball
    ctx.shadowColor = '#fff';
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#fff';
    ctx.fillRect(ball.current.x, ball.current.y, ball.current.width, ball.current.height);
    ctx.shadowBlur = 0;
  };

  const gameLoop = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    update();
    draw(ctx);
    requestRef.current = requestAnimationFrame(gameLoop);
  }, [onScore, difficulty, level, speedMult]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight * 0.8;
      ai.current.x = canvas.width - PADDLE_WIDTH - 20;
      ai.current.y = (canvas.height - PADDLE_HEIGHT) / 2;
      player.current.y = (canvas.height - PADDLE_HEIGHT) / 2;
      resetBall(1);
    };

    window.addEventListener('resize', resize);
    resize();

    const handleInput = (y: number) => {
      player.current.y = y - (player.current.height / 2);
    };

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      handleInput(e.clientY - rect.top);
    };

    const onTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      handleInput(e.touches[0].clientY - rect.top);
    };

    const onKeyDown = (e: KeyboardEvent) => {
      const jump = difficulty === Difficulty.HARD ? 80 : 50;
      if (e.key === 'ArrowUp') player.current.y -= jump;
      if (e.key === 'ArrowDown') player.current.y += jump;
    };

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('keydown', onKeyDown);

    requestRef.current = requestAnimationFrame(gameLoop);

    return () => {
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('keydown', onKeyDown);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameLoop, difficulty]);

  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-full cursor-none block"
    />
  );
};

export default PongCanvas;
