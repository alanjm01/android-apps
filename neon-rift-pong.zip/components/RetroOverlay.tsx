
import React from 'react';

const RetroOverlay: React.FC = () => {
  return (
    <>
      <div className="crt-overlay" />
      <div className="scanline" />
      <div className="absolute inset-0 pointer-events-none flicker z-50 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-cyan-500 opacity-[0.02]" />
      </div>
    </>
  );
};

export default RetroOverlay;
