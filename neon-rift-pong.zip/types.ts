
export interface Entity {
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
}

export interface Ball extends Entity {
  dx: number;
  dy: number;
  speed: number;
  radius: number;
}

export interface Paddle extends Entity {
  score: number;
  speed: number;
}

export enum GameStatus {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  GAMEOVER = 'GAMEOVER',
  PAUSED = 'PAUSED'
}

export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export interface Comment {
  text: string;
  sender: 'Gemini' | 'System';
  timestamp: number;
}
