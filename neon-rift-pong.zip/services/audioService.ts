
class AudioService {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;
  private bgmGain: GainNode | null = null;
  private isBgmPlaying: boolean = false;
  private bgmInterval: number | null = null;
  private step: number = 0;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.bgmGain = this.ctx.createGain();
      this.bgmGain.connect(this.ctx.destination);
      this.bgmGain.gain.setValueAtTime(this.muted ? 0 : 0.04, this.ctx.currentTime);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(val: boolean) {
    this.muted = val;
    if (this.bgmGain && this.ctx) {
      this.bgmGain.gain.setTargetAtTime(val ? 0 : 0.04, this.ctx.currentTime, 0.1);
    }
  }

  public isMuted() {
    return this.muted;
  }

  private createOscillator(freq: number, type: OscillatorType, duration: number, volume: number = 0.1, targetGain?: GainNode) {
    if (!this.ctx) return;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    
    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(targetGain || this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  public startBGM() {
    this.init();
    if (this.isBgmPlaying) return;
    this.isBgmPlaying = true;
    
    const tempo = 160; // Further increased BPM for high energy
    const eighthNoteTime = (60 / tempo) / 2;

    this.bgmInterval = window.setInterval(() => {
      if (!this.ctx || this.ctx.state === 'suspended') return;

      const now = this.ctx.currentTime;
      
      // Bass line (eighth notes)
      const bassFreqs = [55, 55, 55, 55, 48.99, 48.99, 65.41, 65.41]; // A1, A1, A1, A1, G1, G1, C2, C2
      const currentBassFreq = bassFreqs[Math.floor(this.step / 2) % bassFreqs.length];
      this.createOscillator(currentBassFreq, 'sawtooth', 0.2, 0.5, this.bgmGain!);

      // Arpeggio / Melody (on quarter notes or specific steps)
      if (this.step % 4 === 0) {
        const melodyFreqs = [220, 261.63, 329.63, 392.00]; // A3, C4, E4, G4
        const mFreq = melodyFreqs[(this.step / 4) % melodyFreqs.length];
        this.createOscillator(mFreq, 'square', 0.4, 0.2, this.bgmGain!);
      }

      this.step++;
    }, eighthNoteTime * 1000);
  }

  public stopBGM() {
    if (this.bgmInterval) {
      clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
    this.isBgmPlaying = false;
  }

  public playPaddleHit() {
    this.init();
    this.createOscillator(250, 'square', 0.1, 0.05);
  }

  public playWallBounce() {
    this.init();
    this.createOscillator(150, 'sine', 0.05, 0.03);
  }

  public playScorePlayer() {
    this.init();
    [440, 554, 659].forEach((f, i) => {
      setTimeout(() => this.createOscillator(f, 'square', 0.2, 0.05), i * 100);
    });
  }

  public playScoreAI() {
    this.init();
    [300, 200, 150].forEach((f, i) => {
      setTimeout(() => this.createOscillator(f, 'sawtooth', 0.3, 0.04), i * 150);
    });
  }

  public playGameOver() {
    this.init();
    const frequencies = [400, 300, 200, 100];
    frequencies.forEach((f, i) => {
      setTimeout(() => this.createOscillator(f, 'sawtooth', 0.5, 0.05), i * 200);
    });
  }
}

export const audioService = new AudioService();
