
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getGameCommentary = async (
  playerScore: number, 
  aiScore: number, 
  lastEvent: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a snarky 1980s retro arcade machine named "NEON-X". 
      The current Pong game state is: Player ${playerScore}, AI ${aiScore}. 
      The last event was: ${lastEvent}.
      Provide a short, one-sentence punchy comment in character. Use caps occasionally. 
      Keep it under 15 words.`,
      config: {
        temperature: 0.9,
        topP: 0.8,
        maxOutputTokens: 50,
      }
    });

    return response.text || "KEEP PLAYING, MEATBAG.";
  } catch (error) {
    console.error("Gemini Commentary Error:", error);
    return "CONNECTION INTERRUPTED. SYSTEM ERROR.";
  }
};
