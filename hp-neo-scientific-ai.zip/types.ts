
export enum KeyType {
  NUMBER = 'NUMBER',
  OPERATOR = 'OPERATOR',
  FUNCTION = 'FUNCTION',
  STACK = 'STACK',
  AI = 'AI',
  MODIFIER = 'MODIFIER',
  MACRO = 'MACRO',
  EQUALS = 'EQUALS'
}

export interface MacroStep {
  label: string;
  type: KeyType;
}

export interface CalculatorState {
  stack: number[];
  inputBuffer: string;
  isDegrees: boolean;
  shiftMode: 'none' | 'gold' | 'blue';
  lastX: number;
  history: number[];
  statsData: number[];
  activeMatrix?: number[][];
  macros: Record<string, MacroStep[]>;
  recordingKey: string | null;
  isPrgmMode: boolean;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface UnitCategory {
  name: string;
  units: string[];
}
