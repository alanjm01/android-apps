
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const askMathAI = async (prompt: string, currentStack: number[]) => {
  const systemInstruction = `
    You are an expert mathematical assistant integrated into a high-end HP scientific RPN calculator.
    The user is currently working with a stack-based (RPN) calculator.
    Current calculator stack (top index 0 is X, 1 is Y, 2 is Z, 3 is T): ${JSON.stringify(currentStack)}.
    
    Capabilities:
    1. Symbolic Calculus: Perform derivatives and integrals. Explain the steps.
    2. Matrix Operations: Handle matrix multiplication, inversion, and determinants.
    3. Statistics: Explain regression analysis, probability distributions, and hypothesis testing.
    4. Unit Conversion: Convert between any units (metric, imperial, currency, etc.).
    5. Formatting: If you calculate a final numerical result, ALWAYS prefix it with "RESULT: " (e.g., RESULT: 42.0).
    
    Guidelines:
    - Be concise but rigorous.
    - Use LaTeX or clear text formatting for formulas.
    - If the user asks for currency, use your general knowledge of recent rates but add a disclaimer.
    - Suggest the exact RPN keystrokes for simple parts of the problem.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.4,
      },
    });

    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error: Unable to connect to AI assistant. Please check your connection.";
  }
};
