
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { CalculatorState, KeyType, ChatMessage, MacroStep } from './types';
import { askMathAI } from './services/geminiService';
import { 
  History, 
  Sparkles,
  Send,
  X,
  Scale,
  Sigma,
  Calculator,
  Trash2,
  Copy,
  ChevronRight,
  Globe,
  Grid3X3,
  Maximize2,
  Table as TableIcon,
  Play,
  Circle
} from 'lucide-react';

// --- Components ---

const MatrixDisplay: React.FC<{ matrix: number[][]; title?: string; onClose?: () => void }> = ({ matrix, title, onClose }) => {
  return (
    <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl overflow-hidden shadow-xl max-w-full">
      <div className="p-3 bg-[#222] border-b border-white/5 flex justify-between items-center">
        <h3 className="text-xs font-bold uppercase tracking-tighter flex items-center gap-2 opacity-60">
          <Grid3X3 className="w-3 h-3 text-blue-400" />
          {title || "Matrix View"}
        </h3>
        {onClose && (
          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      <div className="p-4 overflow-x-auto">
        <div 
          className="grid gap-2 min-w-max" 
          style={{ gridTemplateColumns: `repeat(${matrix[0]?.length || 1}, minmax(60px, 1fr))` }}
        >
          {matrix.map((row, rIdx) => (
            row.map((cell, cIdx) => (
              <div 
                key={`${rIdx}-${cIdx}`}
                className="bg-[#2c3e2b] border border-[#5a6b58] p-2 text-right lcd-font text-[#8fa18c] text-sm rounded shadow-inner"
              >
                {cell.toLocaleString(undefined, { maximumFractionDigits: 4 })}
              </div>
            ))
          ))}
        </div>
      </div>
      <div className="px-4 pb-3 text-[10px] opacity-30 uppercase font-bold">
        {matrix.length} × {matrix[0]?.length || 0} Dimensions
      </div>
    </div>
  );
};

const Display: React.FC<{ state: CalculatorState }> = ({ state }) => {
  const { stack, inputBuffer, recordingKey, isPrgmMode } = state;
  const xValue = inputBuffer || (stack[0]?.toString() || "0");
  const yValue = stack[1]?.toString() || "0";
  const zValue = stack[2]?.toString() || "0";
  const tValue = stack[3]?.toString() || "0";

  return (
    <div className="bg-[#8fa18c] p-4 rounded-md shadow-inner border-4 border-[#5a6b58] mb-4 flex flex-col justify-end items-end h-40 overflow-hidden relative">
      <div className="absolute top-2 left-4 flex flex-wrap gap-2 text-[10px] text-[#2c3e2b] font-bold opacity-70">
        <span className={state.isDegrees ? 'underline' : ''}>DEG</span>
        <span className={!state.isDegrees ? 'underline' : ''}>RAD</span>
        <span className="ml-2">Σ:{state.statsData.length}</span>
        {isPrgmMode && <span className="text-red-800 animate-pulse">PRGM</span>}
        {recordingKey && <span className="bg-red-800 text-[#8fa18c] px-1 ml-1">REC {recordingKey}</span>}
        {state.shiftMode !== 'none' && (
          <span className="bg-[#2c3e2b] text-[#8fa18c] px-1 uppercase">{state.shiftMode}</span>
        )}
      </div>
      
      <div className="w-full flex flex-col gap-1 lcd-font text-[#1a2619] tracking-tight">
        <div className="text-xs opacity-40 flex justify-between w-full"><span>T:</span> <span>{tValue}</span></div>
        <div className="text-xs opacity-50 flex justify-between w-full"><span>Z:</span> <span>{zValue}</span></div>
        <div className="text-sm opacity-70 flex justify-between w-full"><span>Y:</span> <span>{yValue}</span></div>
        <div className="text-3xl font-bold flex justify-between w-full mt-1 border-t border-[#1a2619]/10 pt-1">
          <span>X:</span> 
          <span className="truncate ml-4">{xValue}</span>
        </div>
      </div>
    </div>
  );
};

const Key: React.FC<{ 
  label: string; 
  subLabel?: string; 
  topLabel?: string;
  type?: KeyType;
  onClick: () => void;
  className?: string;
  shiftMode: 'none' | 'gold' | 'blue';
  isActive?: boolean;
}> = ({ label, subLabel, topLabel, onClick, className, shiftMode, isActive }) => {
  const getLabelColor = () => {
    if (shiftMode === 'gold' && topLabel) return 'text-[#ffc107]';
    if (shiftMode === 'blue' && subLabel) return 'text-[#2196f3]';
    return 'text-white';
  };

  const getActiveLabel = () => {
    if (shiftMode === 'gold' && topLabel) return topLabel;
    if (shiftMode === 'blue' && subLabel) return subLabel;
    return label;
  };

  return (
    <button 
      onClick={onClick}
      className={`
        relative flex flex-col items-center justify-center p-2 rounded-md transition-all active:scale-95 active:bg-opacity-80
        ${isActive ? 'ring-2 ring-blue-500 bg-blue-500/20 shadow-none translate-y-1' : (className || 'bg-[#333] hover:bg-[#444] shadow-[0_4px_0_rgb(30,30,30)] active:shadow-none active:translate-y-1')}
        key
      `}
    >
      {topLabel && (
        <span className="absolute -top-5 text-[10px] font-bold text-[#ffc107] uppercase truncate max-w-full">
          {topLabel}
        </span>
      )}
      <span className={`text-lg font-bold ${getLabelColor()}`}>{getActiveLabel()}</span>
      {subLabel && (
        <span className="absolute -bottom-5 text-[10px] font-bold text-[#2196f3] uppercase truncate max-w-full">
          {subLabel}
        </span>
      )}
    </button>
  );
};

const HistoryDrawer: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  history: number[];
  onSelect: (val: number) => void;
  onClear: () => void;
}> = ({ isOpen, onClose, history, onSelect, onClear }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[60] flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-72 bg-[#1a1a1a] h-full shadow-2xl border-l border-white/10 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="p-4 border-b border-white/10 flex justify-between items-center bg-[#222]">
          <h2 className="font-bold flex items-center gap-2"><History className="w-4 h-4"/> History</h2>
          <button onClick={onClear} className="p-1 text-red-400 hover:bg-red-400/10 rounded" title="Clear History">
            <Trash2 className="w-4 h-4"/>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {history.length === 0 ? (
            <div className="p-8 text-center opacity-30 text-sm">No recent calculations</div>
          ) : (
            history.map((val, i) => (
              <button 
                key={i} 
                onClick={() => onSelect(val)}
                className="w-full text-right p-3 hover:bg-white/5 rounded-lg border border-transparent hover:border-white/10 transition-colors group"
              >
                <div className="text-xs opacity-40 mb-1 flex justify-between">
                  <span>Entry {history.length - i}</span>
                  <Copy className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="font-mono text-lg font-bold">{val}</div>
              </button>
            ))
          )}
        </div>
        <button onClick={onClose} className="p-4 text-center text-sm opacity-50 hover:opacity-100">Close</button>
      </div>
    </div>
  );
};

const ToolsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onAction: (prompt: string) => void;
  onViewMatrix: () => void;
}> = ({ isOpen, onClose, onAction, onViewMatrix }) => {
  if (!isOpen) return null;
  
  const toolGroups = [
    {
      title: "Unit Conversion",
      icon: <Scale className="w-4 h-4" />,
      actions: [
        { label: "Metric to Imperial", prompt: "Convert current stack value from Metric to Imperial (e.g., meters to feet, kg to lbs)." },
        { label: "Temp (C to F)", prompt: "Convert current value from Celsius to Fahrenheit." },
        { label: "Currency (Live)", prompt: "Convert current value between major currencies using current estimated rates." }
      ]
    },
    {
      title: "Calculus & Algebra",
      icon: <Calculator className="w-4 h-4" />,
      actions: [
        { label: "Differentiate", prompt: "Explain and calculate the derivative of the current mathematical expression context." },
        { label: "Integrate", prompt: "Explain and calculate the definite/indefinite integral of the current context." },
        { label: "Matrix Operations", prompt: "Help me perform matrix multiplication, inversion, or determinant calculation." },
        { label: "View Active Matrix", action: onViewMatrix }
      ]
    },
    {
      title: "Statistics",
      icon: <Sigma className="w-4 h-4" />,
      actions: [
        { label: "Regression", prompt: "Perform a linear regression analysis on my statistical data buffer." },
        { label: "Std Deviation", prompt: "Calculate the standard deviation and variance of my current data." }
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-[#222] w-full max-w-sm rounded-2xl border border-white/10 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        <div className="p-4 bg-[#333] border-b border-white/10 flex justify-between items-center">
          <h2 className="font-bold flex items-center gap-2"><Globe className="w-4 h-4 text-blue-400"/> Neo-Tools</h2>
          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full"><X className="w-5 h-5"/></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {toolGroups.map((group, idx) => (
            <div key={idx} className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-50 px-1">
                {group.icon}
                {group.title}
              </div>
              <div className="grid grid-cols-1 gap-2">
                {group.actions.map((act, aIdx) => (
                  <button 
                    key={aIdx} 
                    onClick={() => { 
                      if (act.prompt) onAction(act.prompt); 
                      if (act.action) act.action();
                      onClose(); 
                    }}
                    className="flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 rounded-xl text-sm transition-colors text-left"
                  >
                    <span>{act.label}</span>
                    <ChevronRight className="w-4 h-4 opacity-30" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const AIAssistant: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  stack: number[];
  initialPrompt?: string;
  onResultReceived: (val: number) => void;
  onMatrixDetected: (matrix: number[][]) => void;
}> = ({ isOpen, onClose, stack, initialPrompt, onResultReceived, onMatrixDetected }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSend(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (overrideInput?: string) => {
    const text = overrideInput || input;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const response = await askMathAI(text, stack);
    
    // Result Extraction
    const resultMatch = response.match(/RESULT:\s*(-?\d+(\.\d+)?)/i);
    if (resultMatch) {
      onResultReceived(parseFloat(resultMatch[1]));
    }

    // Matrix Extraction (Looking for [[...]] patterns)
    const matrixMatch = response.match(/\[\[[\s\S]*?\]\]/);
    if (matrixMatch) {
      try {
        const matrixData = JSON.parse(matrixMatch[0]);
        if (Array.isArray(matrixData) && Array.isArray(matrixData[0])) {
          onMatrixDetected(matrixData);
        }
      } catch (e) { console.warn("Failed to parse detected matrix", e); }
    }

    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  const renderMessageContent = (content: string) => {
    // Basic detection for matrices within the chat content
    const matrixRegex = /\[\[[\s\S]*?\]\]/g;
    const parts = content.split(matrixRegex);
    const matches = content.match(matrixRegex);

    if (!matches) return content;

    return (
      <div className="space-y-4">
        {parts.map((part, i) => (
          <React.Fragment key={i}>
            <p>{part}</p>
            {matches[i] && (
              <div className="my-2">
                <MatrixDisplay matrix={JSON.parse(matches[i])} />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#1a1a1a] w-full max-w-md h-[85vh] rounded-3xl border border-white/10 flex flex-col shadow-2xl overflow-hidden ring-1 ring-white/5">
        <div className="p-4 bg-[#222] border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="text-yellow-400 w-5 h-5 animate-pulse" />
            <h2 className="font-bold text-lg">AI Math Expert</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-transparent to-white/5">
          {messages.length === 0 && !isLoading && (
            <div className="h-full flex flex-col items-center justify-center opacity-30 text-center px-8">
              <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mb-4">
                <Calculator className="w-8 h-8 text-blue-400" />
              </div>
              <p className="text-sm">Ready for complex calculus, matrix math, or unit conversions.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[95%] p-4 rounded-2xl text-sm leading-relaxed ${
                m.role === 'user' ? 'bg-blue-600 shadow-lg' : 'bg-[#333] border border-white/10'
              }`}>
                {renderMessageContent(m.content)}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-[#333] p-4 rounded-2xl animate-pulse flex gap-2">
                <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 bg-white/50 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-white/10 bg-[#222]">
          <div className="flex gap-3">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask for math help..."
              className="flex-1 bg-[#0a0a0a] border border-white/10 rounded-2xl px-5 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-white/20"
            />
            <button 
              onClick={() => handleSend()}
              disabled={isLoading}
              className="p-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-2xl transition-all shadow-lg active:scale-95 flex items-center justify-center"
            >
              <Send className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App Logic ---

export default function App() {
  const [state, setState] = useState<CalculatorState>({
    stack: [0, 0, 0, 0],
    inputBuffer: '',
    isDegrees: true,
    shiftMode: 'none',
    lastX: 0,
    history: [],
    statsData: [],
    activeMatrix: undefined,
    macros: { P1: [], P2: [], P3: [] },
    recordingKey: null,
    isPrgmMode: false
  });
  
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState<string | undefined>(undefined);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [isMatrixModalOpen, setIsMatrixModalOpen] = useState(false);

  // Define handleKey before it's used in playback
  const handleKey = useCallback((label: string, type: KeyType) => {
    setState(prev => {
      // Handle Macro Recording Interception
      if (prev.recordingKey && type !== KeyType.MACRO && label !== 'PRGM') {
        const newMacros = { ...prev.macros };
        newMacros[prev.recordingKey] = [...(newMacros[prev.recordingKey] || []), { label, type }];
        return { ...prev, macros: newMacros };
      }

      const { stack, inputBuffer, isDegrees, shiftMode, statsData, recordingKey, macros, isPrgmMode } = prev;
      const x = parseFloat(inputBuffer || stack[0].toString());

      if (type === KeyType.MODIFIER) {
        if (label === 'GOLD') return { ...prev, shiftMode: prev.shiftMode === 'gold' ? 'none' : 'gold' };
        if (label === 'BLUE') return { ...prev, shiftMode: prev.shiftMode === 'blue' ? 'none' : 'blue' };
        if (label === 'PRGM') return { ...prev, isPrgmMode: !prev.isPrgmMode, recordingKey: null };
        return prev;
      }

      if (type === KeyType.EQUALS) {
        // EQUALS Logic: Enter current buffer, then ask AI to Solve/Summarize.
        let finalState = { ...prev };
        if (inputBuffer) {
          const val = parseFloat(inputBuffer);
          finalState = {
            ...finalState,
            stack: [val, finalState.stack[0], finalState.stack[1], finalState.stack[2]],
            inputBuffer: '',
            history: [val, ...finalState.history].slice(0, 50)
          };
        }
        
        // Use a side-effect to open the AI modal
        setTimeout(() => {
          handleAction("Explain the current stack and provide the final result of this calculation.");
        }, 10);
        
        return finalState;
      }

      if (type === KeyType.MACRO) {
        if (isPrgmMode) {
          // Toggle recording for this key
          if (recordingKey === label) return { ...prev, recordingKey: null };
          return { ...prev, recordingKey: label, macros: { ...macros, [label]: [] } };
        } else {
          return prev;
        }
      }

      if (type === KeyType.NUMBER) {
        if (label === '.' && inputBuffer.includes('.')) return prev;
        return { ...prev, inputBuffer: prev.inputBuffer + label };
      }

      if (type === KeyType.STACK) {
        if (label === 'ENTER') {
          const val = parseFloat(inputBuffer || stack[0].toString());
          return {
            ...prev,
            stack: [val, prev.stack[0], prev.stack[1], prev.stack[2]],
            inputBuffer: '',
            shiftMode: 'none',
            history: [val, ...prev.history].slice(0, 50)
          };
        } else if (label === 'CLX') {
          if (inputBuffer) return { ...prev, inputBuffer: '' };
          const newStack = [...stack];
          newStack[0] = 0;
          return { ...prev, stack: newStack, inputBuffer: '', shiftMode: 'none' };
        } else if (label === 'SWAP') {
          const newStack = [...stack];
          const currentX = parseFloat(inputBuffer || stack[0].toString());
          newStack[0] = stack[1];
          newStack[1] = currentX;
          return { ...prev, stack: newStack, inputBuffer: '', shiftMode: 'none' };
        } else if (label === 'ROLL') {
          const newStack = [stack[1], stack[2], stack[3], stack[0]];
          return { ...prev, stack: newStack, inputBuffer: '', shiftMode: 'none' };
        }
        return prev;
      }

      if (type === KeyType.OPERATOR) {
        const y = stack[1];
        let result = 0;
        switch(label) {
          case '+': result = y + x; break;
          case '-': result = y - x; break;
          case '×': result = y * x; break;
          case '÷': result = y / x; break;
          case 'y^x': result = Math.pow(y, x); break;
        }
        return {
          ...prev,
          stack: [result, prev.stack[2], prev.stack[3], 0],
          inputBuffer: '',
          lastX: x,
          shiftMode: 'none',
          history: [result, ...prev.history].slice(0, 50)
        };
      }

      if (type === KeyType.FUNCTION) {
        let result = 0;
        const angleMultiplier = isDegrees ? (Math.PI / 180) : 1;
        const inverseAngleMultiplier = isDegrees ? (180 / Math.PI) : 1;

        if (label === 'Σ+') return { ...prev, statsData: [...prev.statsData, x], inputBuffer: '', shiftMode: 'none' };
        if (label === 'Σ-') {
          const newData = [...statsData];
          newData.pop();
          return { ...prev, statsData: newData, inputBuffer: '', shiftMode: 'none' };
        }
        if (label === 'MEAN') {
          if (statsData.length === 0) return prev;
          result = statsData.reduce((a, b) => a + b, 0) / statsData.length;
        } else {
          switch(label) {
            case 'SIN': result = Math.sin(x * angleMultiplier); break;
            case 'COS': result = Math.cos(x * angleMultiplier); break;
            case 'TAN': result = Math.tan(x * angleMultiplier); break;
            case 'ASIN': result = Math.asin(x) * inverseAngleMultiplier; break;
            case 'ACOS': result = Math.acos(x) * inverseAngleMultiplier; break;
            case 'ATAN': result = Math.atan(x) * inverseAngleMultiplier; break;
            case 'SQRT': result = Math.sqrt(x); break;
            case '1/x': result = 1 / x; break;
            case 'LOG': result = Math.log10(x); break;
            case 'LN': result = Math.log(x); break;
            case 'e^x': result = Math.exp(x); break;
            case 'x²': result = x * x; break;
            case 'π': result = Math.PI; break;
          }
        }
        const newStack = [...prev.stack];
        const oldX = newStack[0];
        newStack[0] = result;
        return { 
          ...prev, 
          stack: newStack, 
          inputBuffer: '', 
          lastX: oldX,
          shiftMode: 'none',
          history: [result, ...prev.history].slice(0, 50)
        };
      }
      return prev;
    });
  }, []);

  const runMacro = useCallback((id: string) => {
    const sequence = state.macros[id];
    if (!sequence || sequence.length === 0) return;
    
    sequence.forEach(step => {
      handleKey(step.label, step.type);
    });
  }, [state.macros, handleKey]);

  // Wrapper for UI clicks to handle Macro playback
  const onKeyClick = (label: string, type: KeyType) => {
    if (type === KeyType.MACRO && !state.isPrgmMode) {
      runMacro(label);
    } else {
      handleKey(label, type);
    }
  };

  const pushToStack = useCallback((val: number) => {
    setState(prev => ({
      ...prev,
      stack: [val, prev.stack[0], prev.stack[1], prev.stack[2]],
      inputBuffer: '',
      shiftMode: 'none',
      history: [val, ...prev.history].slice(0, 50)
    }));
  }, []);

  const handleAction = (prompt: string) => {
    setAiPrompt(prompt);
    setIsAIModalOpen(true);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#111] pb-[calc(1rem+env(safe-area-inset-bottom))] pt-[calc(1rem+env(safe-area-inset-top))]">
      <div className="w-full max-w-sm bg-[#1a1a1a] p-5 rounded-[2.5rem] border-[6px] border-[#333] shadow-2xl relative overflow-hidden">
        <div className="flex justify-between items-center mb-6 px-2">
          <div className="flex gap-2">
            <button 
              onClick={() => setIsHistoryOpen(true)}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
              title="History"
            >
              <History className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setIsToolsOpen(true)}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
              title="Unit Tools"
            >
              <Scale className="w-4 h-4" />
            </button>
          </div>
          <button 
            onClick={() => { setAiPrompt(undefined); setIsAIModalOpen(true); }}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-2xl text-xs font-bold text-white shadow-lg active:scale-95 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            AI ASSIST
          </button>
        </div>

        <Display state={state} />

        {/* Dynamic Matrix Preview in Display Area if exists */}
        {state.activeMatrix && (
          <div className="absolute top-28 left-8 right-8 animate-in slide-in-from-bottom duration-300">
             <button 
              onClick={() => setIsMatrixModalOpen(true)}
              className="w-full bg-[#2c3e2b]/80 backdrop-blur border border-[#5a6b58] rounded p-2 flex items-center justify-between text-[10px] text-[#8fa18c] font-bold uppercase"
             >
                <div className="flex items-center gap-2">
                  <Grid3X3 className="w-3 h-3" />
                  Active Matrix Loaded
                </div>
                <Maximize2 className="w-3 h-3" />
             </button>
          </div>
        )}

        <div className="grid grid-cols-4 gap-x-3 gap-y-7 mt-6">
          <Key label="P1" isActive={state.recordingKey === 'P1'} onClick={() => onKeyClick('P1', KeyType.MACRO)} shiftMode={state.shiftMode} />
          <Key label="P2" isActive={state.recordingKey === 'P2'} onClick={() => onKeyClick('P2', KeyType.MACRO)} shiftMode={state.shiftMode} />
          <Key label="P3" isActive={state.recordingKey === 'P3'} onClick={() => onKeyClick('P3', KeyType.MACRO)} shiftMode={state.shiftMode} />
          <Key label="PRGM" className={`bg-[#444] ${state.isPrgmMode ? 'text-red-500 shadow-none ring-2 ring-red-500/50' : 'text-white'}`} onClick={() => onKeyClick('PRGM', KeyType.MODIFIER)} shiftMode={state.shiftMode} />

          <Key label="Σ+" topLabel="MEAN" subLabel="Σ-" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'MEAN' : (state.shiftMode === 'blue' ? 'Σ-' : 'Σ+'), KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="y^x" topLabel="LN" subLabel="e^x" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'LN' : (state.shiftMode === 'blue' ? 'e^x' : 'y^x'), KeyType.OPERATOR)} shiftMode={state.shiftMode} />
          <Key label="LOG" topLabel="10^x" onClick={() => onKeyClick('LOG', KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="÷" className="bg-[#444] text-blue-400" onClick={() => onKeyClick('÷', KeyType.OPERATOR)} shiftMode={state.shiftMode} />

          <Key label="SIN" topLabel="ASIN" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'ASIN' : 'SIN', KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="COS" topLabel="ACOS" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'ACOS' : 'COS', KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="TAN" topLabel="ATAN" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'ATAN' : 'TAN', KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="×" className="bg-[#444] text-blue-400" onClick={() => onKeyClick('×', KeyType.OPERATOR)} shiftMode={state.shiftMode} />

          <Key label="1/x" topLabel="SQRT" subLabel="x²" onClick={() => onKeyClick(state.shiftMode === 'gold' ? 'SQRT' : (state.shiftMode === 'blue' ? 'x²' : '1/x'), KeyType.FUNCTION)} shiftMode={state.shiftMode} />
          <Key label="GOLD" className={`bg-[#ffc107]/10 text-[#ffc107] border border-[#ffc107]/20 ${state.shiftMode === 'gold' ? 'ring-2 ring-[#ffc107]' : ''}`} onClick={() => onKeyClick('GOLD', KeyType.MODIFIER)} shiftMode={state.shiftMode} />
          <Key label="BLUE" className={`bg-[#2196f3]/10 text-[#2196f3] border border-[#2196f3]/20 ${state.shiftMode === 'blue' ? 'ring-2 ring-[#2196f3]' : ''}`} onClick={() => onKeyClick('BLUE', KeyType.MODIFIER)} shiftMode={state.shiftMode} />
          <Key label="-" className="bg-[#444] text-blue-400" onClick={() => onKeyClick('-', KeyType.OPERATOR)} shiftMode={state.shiftMode} />

          <div className="grid grid-cols-4 col-span-4 gap-3">
            <div className="col-span-1 grid grid-rows-4 gap-y-7">
              <Key label="7" onClick={() => onKeyClick('7', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="4" onClick={() => onKeyClick('4', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="1" onClick={() => onKeyClick('1', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="0" onClick={() => onKeyClick('0', KeyType.NUMBER)} shiftMode={state.shiftMode} />
            </div>
            <div className="col-span-1 grid grid-rows-4 gap-y-7">
              <Key label="8" onClick={() => onKeyClick('8', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="5" onClick={() => onKeyClick('5', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="2" onClick={() => onKeyClick('2', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="." onClick={() => onKeyClick('.', KeyType.NUMBER)} shiftMode={state.shiftMode} />
            </div>
            <div className="col-span-1 grid grid-rows-4 gap-y-7">
              <Key label="9" onClick={() => onKeyClick('9', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="6" onClick={() => onKeyClick('6', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="3" onClick={() => onKeyClick('3', KeyType.NUMBER)} shiftMode={state.shiftMode} />
              <Key label="CLX" topLabel="EEX" onClick={() => onKeyClick('CLX', KeyType.STACK)} shiftMode={state.shiftMode} />
            </div>
            <div className="col-span-1 flex flex-col gap-3">
              <Key label="ENT" className="flex-1 bg-white/10 text-white font-black" onClick={() => onKeyClick('ENTER', KeyType.STACK)} shiftMode={state.shiftMode} />
              <Key label="+" className="h-16 bg-[#444] text-blue-400" onClick={() => onKeyClick('+', KeyType.OPERATOR)} shiftMode={state.shiftMode} />
              <Key label="=" className="h-16 bg-blue-600 text-white font-black shadow-[0_4px_0_rgb(29,78,216)]" onClick={() => onKeyClick('=', KeyType.EQUALS)} shiftMode={state.shiftMode} />
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-center gap-4 opacity-20 text-[7px] uppercase font-bold tracking-[0.3em]">
          <span>Advanced AI Logic</span>
          <span>•</span>
          <span>Macro PRGM</span>
          <span>•</span>
          <span>Stats Σ+</span>
        </div>
      </div>

      <HistoryDrawer 
        isOpen={isHistoryOpen} 
        onClose={() => setIsHistoryOpen(false)} 
        history={state.history} 
        onSelect={(v) => { pushToStack(v); setIsHistoryOpen(false); }}
        onClear={() => setState(s => ({ ...s, history: [] }))}
      />

      <ToolsModal 
        isOpen={isToolsOpen} 
        onClose={() => setIsToolsOpen(false)} 
        onAction={handleAction} 
        onViewMatrix={() => setIsMatrixModalOpen(true)}
      />

      <AIAssistant 
        isOpen={isAIModalOpen} 
        onClose={() => { setIsAIModalOpen(false); setAiPrompt(undefined); }} 
        stack={state.stack}
        initialPrompt={aiPrompt}
        onResultReceived={(val) => pushToStack(val)}
        onMatrixDetected={(mat) => setState(s => ({ ...s, activeMatrix: mat }))}
      />

      {/* Standalone Matrix Viewer Modal */}
      {isMatrixModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg">
            {state.activeMatrix ? (
              <MatrixDisplay 
                matrix={state.activeMatrix} 
                title="Matrix Data Editor" 
                onClose={() => setIsMatrixModalOpen(false)} 
              />
            ) : (
              <div className="bg-[#222] p-8 rounded-3xl border border-white/10 text-center space-y-4">
                <TableIcon className="w-12 h-12 mx-auto text-white/20" />
                <h3 className="text-xl font-bold">No Active Matrix</h3>
                <p className="text-white/40 text-sm">Ask the AI assistant to perform matrix operations or provide a matrix.</p>
                <button 
                  onClick={() => setIsMatrixModalOpen(false)}
                  className="px-6 py-2 bg-white/10 rounded-full text-sm font-bold"
                >
                  Dismiss
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
